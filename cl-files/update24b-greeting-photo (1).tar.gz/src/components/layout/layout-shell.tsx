"use client"
import { Suspense, useEffect, useMemo, useRef, useState } from "react"
import Link from "next/link"
import { usePathname, useRouter, useSearchParams } from "next/navigation"
import { Menu, Search } from "lucide-react"
import { SidebarProvider, useSidebar } from "@/components/ui/sidebar"
import { useTrackPageView } from "@/hooks/use-track-page-view"
import { useUser, useDoc, useFirestore } from "@/firebase"
import { doc } from "firebase/firestore"
import { usePlan } from "@/hooks/use-plan"
import { TopSearchProvider, useTopSearchState } from "@/components/layout/top-search"
import dynamic from "next/dynamic"
import { PlanRouteGuard } from "@/components/layout/plan-route-guard"
import { UsageTracker } from "@/components/layout/usage-tracker"
const AppSidebar = dynamic(() => import("@/components/layout/app-sidebar").then(mod => mod.AppSidebar), { ssr: false })

// The five dashboard sections. Each opens the dashboard on that section; `match` keeps the right one lit on its own pages.
const TABS = [
  { label: "Home", key: "home", icon: "🏠", match: ["/streak"] },
  { label: "Notes", key: "notes", icon: "📚", match: ["/notes", "/top-100", "/university-exams", "/flashcards", "/mindmaps", "/drug-classification"] },
  { label: "QBank", key: "qbank", icon: "🎯", match: ["/qbank", "/test-series"] },
  { label: "Test", key: "test", icon: "⏱️", match: ["/grand-test", "/pyq"] },
  { label: "Bedside", key: "bedside", icon: "🩺", match: ["/cases", "/case-presentation", "/virtual-patient", "/arena"] },
]

function TopBar() {
  const { toggleSidebar } = useSidebar()
  const { user } = useUser()
  const { isPro, isBasic } = usePlan()
  const router = useRouter()
  const [q, setQ] = useState("")
  const ts = useTopSearchState()
  const scoped = ts?.placeholder ?? null
  const planLabel = isPro ? "Clinician" : isBasic ? "Scholar" : "Explorer"
  const db = useFirestore()
  const profileRef = useMemo(() => (!db || !user) ? null : doc(db, "users", user.uid), [db, user])
  const { data: prof } = useDoc(profileRef)
  const photo: string = (prof as any)?.photoData || user?.photoURL || ""
  const initial = (user?.displayName || user?.email || "D").trim().charAt(0).toUpperCase()

  return (
    <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-border bg-white/90 px-4 py-3 backdrop-blur-md md:px-8">
      <button
        onClick={toggleSidebar}
        aria-label="Toggle menu"
        className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-border bg-white text-foreground transition-colors hover:bg-accent"
      >
        <Menu className="h-5 w-5" />
      </button>
      {scoped && <form
        onSubmit={(e) => { e.preventDefault(); if (!scoped && q.trim()) router.push(`/search?q=${encodeURIComponent(q.trim())}`) }}
        className="flex max-w-md flex-1 items-center gap-2 rounded-[14px] border border-border bg-card px-3.5 py-2.5 text-muted-foreground"
      >
        <Search className="h-4 w-4 shrink-0" />
        <input
          value={scoped ? ts!.query : q}
          onChange={(e) => (scoped ? ts!.setQuery(e.target.value) : setQ(e.target.value))}
          placeholder={scoped || "Search all of QubixPrep…"}
          className="w-full bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground/70"
        />
      </form>}
      <div className="ml-auto flex items-center gap-2.5">
        <Link href="/pricing" className="hidden rounded-full border border-border bg-card px-3.5 py-2 text-[13px] font-bold text-muted-foreground sm:block">
          🎓 {planLabel}
        </Link>
        <Link href="/profile" aria-label="Profile" className="grid h-[38px] w-[38px] place-items-center overflow-hidden rounded-full bg-[#d9f0d9] font-black text-[#316b48]">
          {photo ? <img src={photo} alt="" className="h-full w-full object-cover" /> : initial}
        </Link>
      </div>
    </header>
  )
}

/** On tablets and small laptops the menu starts closed so the page gets the full width. The menu button opens it any time. */
function AutoCollapse() {
  const { setOpen, isMobile } = useSidebar()
  const done = useRef(false)
  useEffect(() => {
    if (done.current) return
    done.current = true
    if (!isMobile && window.innerWidth < 1100) setOpen(false)
  }, [isMobile, setOpen])
  return null
}

function MobileNav() {
  const pathname = usePathname()
  const params = useSearchParams()
  const cur = params.get("tab") || "home"
  return (
    <nav className="fixed inset-x-0 bottom-0 z-30 flex justify-around border-t border-border bg-white/95 px-1 pt-2 backdrop-blur-md md:hidden" style={{ paddingBottom: "max(8px, env(safe-area-inset-bottom))" }}>
      {TABS.map((t) => {
        const on = pathname === "/" ? cur === t.key : t.match.some((m) => pathname.startsWith(m))
        return (
          <Link key={t.key} href={t.key === "home" ? "/" : `/?tab=${t.key}`} className={`grid justify-items-center gap-0.5 px-2 text-[10px] font-extrabold ${on ? "text-primary" : "text-muted-foreground"}`}>
            <span className="text-xl leading-none">{t.icon}</span>
            {t.label}
          </Link>
        )
      })}
    </nav>
  )
}

export function LayoutShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  useTrackPageView()
  const isAuthPage = pathname === "/login" || pathname === "/signup"
  if (isAuthPage) {
    return (
      <main className="min-h-screen w-full bg-background">
        <PlanRouteGuard>{children}</PlanRouteGuard>
      </main>
    )
  }
  return (
    <TopSearchProvider>
    <SidebarProvider defaultOpen={true}>
      <div className="flex min-h-screen w-full bg-background">
        <AppSidebar />
        <div className="flex min-w-0 w-full flex-1 flex-col">
          <TopBar />
          <main className="w-full flex-1 pb-20 md:pb-0">
            {children}
          </main>
        </div>
      </div>
      <AutoCollapse />
      <UsageTracker />
      <Suspense fallback={null}><MobileNav /></Suspense>
    </SidebarProvider>
    </TopSearchProvider>
  )
}
