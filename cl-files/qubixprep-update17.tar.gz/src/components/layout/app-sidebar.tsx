"use client"

import { BrandLockup } from "@/components/brand-mark"
import { useMemo } from "react"
import {
  BookOpen, GraduationCap, Layers, Network, Flame, Database, Trophy, BrainCircuit, Stethoscope,
  Sparkles, Wand2, ShoppingBag, Gift, User, Zap, CloudUpload, Lock, Plus, Star, Newspaper, Swords, HelpCircle, LifeBuoy, RotateCcw, BarChart3, CalendarDays, Timer, Microscope,
} from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useUser, useDoc, useFirestore } from "@/firebase"
import { doc } from "firebase/firestore"
import { usePlan } from "@/hooks/use-plan"
import { QuickCardsMenuItems } from "@/components/quickcards/menu-items"
import { CasePresentationMenuItem } from "@/components/casepres/menu-item"

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarFooter,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar"

const ITEM =
  "mx-2 px-3 h-10 rounded-xl font-semibold text-sidebar-foreground transition-all hover:bg-secondary hover:text-primary data-[active=true]:bg-secondary data-[active=true]:text-primary"

type Item = { title: string; url: string; icon: any; lock?: boolean; also?: string[] }

export function AppSidebar() {
  const pathname = usePathname()
  const { user } = useUser()
  const db = useFirestore()
  const { isMobile, setOpenMobile } = useSidebar()
  const { isFree, isBasic, isPro, canAccessContent, canAccessAI } = usePlan()

  const closeOnMobile = () => {
    if (isMobile) setOpenMobile(false)
  }

  const profileRef = useMemo(() => {
    if (!db || !user) return null
    return doc(db, "users", user.uid)
  }, [db, user])
  const { data: profile } = useDoc(profileRef)
  const isAdmin = profile && (profile as any).role === "admin"
  const year = (profile as any)?.currentYear
  const planLabel = isPro ? "Clinician" : isBasic ? "Scholar" : "Explorer"
  const name = user?.displayName?.split(" ")[0] || "Future doctor"

  const home: Item[] = [
    { title: "Home", url: "/", icon: Zap },
    { title: "Day Streak", url: "/streak", icon: Flame },
    { title: "My Progress", url: "/my-progress", icon: BarChart3, also: ["/review", "/plan"] },
  ]
  const notes: Item[] = [
    { title: "Rapid Revision Notes", url: "/notes", icon: BookOpen },
    { title: "Top 100 Topics", url: "/top-100", icon: Star },
    { title: "University Exams", url: "/university-exams", icon: GraduationCap, also: ["/long-answers", "/spotters"] },
    { title: "Flashcards", url: "/flashcards", icon: Layers },
    // Mind Maps are hidden for everyone for now (admins can still open /mindmaps directly)
  ]
  const stories: Item[] = [{ title: "Med Stories", url: "/stories", icon: Newspaper }]
  const qbank: Item[] = [
    { title: "QBank", url: "/qbank", icon: Database },
    { title: "Custom Quiz", url: "/test-series", icon: BrainCircuit, lock: !canAccessContent },
  ]
  const tests: Item[] = [
    { title: "Grand Test", url: "/grand-test", icon: Timer },
    { title: "PYQ Series", url: "/pyq", icon: Trophy },
  ]
  const bedside: Item[] = [
    { title: "Ward Round", url: "/cases", icon: Stethoscope },
    { title: "Virtual Patient", url: "/virtual-patient", icon: Stethoscope },
    { title: "Arena", url: "/arena", icon: Swords },
  ]
  const studio: Item[] = [
    { title: "Jelly AI", url: "/jelly", icon: Sparkles },
  ]
  const account: Item[] = [
    { title: "Profile & account", url: "/profile", icon: User, also: ["/products", "/affiliate", "/pricing", "/faq", "/support"] },
  ]

  const active = (url: string, also: string[] = []) => (url === "/" ? pathname === "/" : [url, ...also].some((u) => pathname.startsWith(u)))

  const row = (item: Item) => (
    <SidebarMenuItem key={item.title}>
      <SidebarMenuButton asChild isActive={active(item.url, item.also)} tooltip={item.title} className={ITEM}>
        <Link href={item.url} onClick={closeOnMobile}>
          <item.icon className="h-[18px] w-[18px]" />
          <span>{item.title}</span>
          {item.lock && <Lock className="ml-auto h-3 w-3 text-muted-foreground/60" />}
        </Link>
      </SidebarMenuButton>
    </SidebarMenuItem>
  )

  const TAB_OF: Record<string, string> = { Home: "/", Notes: "/?tab=notes", QBank: "/?tab=qbank", Test: "/?tab=test", Bedside: "/?tab=bedside" }
  const label = (t: string) => (
    <SidebarGroupLabel className="px-5 text-[10px] font-black uppercase tracking-[0.15em] text-muted-foreground/70">
      {TAB_OF[t] ? <Link href={TAB_OF[t]} className="hover:text-primary">{t}</Link> : t}
    </SidebarGroupLabel>
  )

  return (
    <Sidebar collapsible="offcanvas" className="border-r border-border bg-sidebar">
      <SidebarHeader className="gap-4 p-4 pb-2">
        <Link href="/" className="flex items-center gap-2.5 px-2 min-w-0" onClick={closeOnMobile}>
          <BrandLockup />
        </Link>
        {user && (
          <Link href="/profile" onClick={closeOnMobile} className="flex items-center gap-2.5 rounded-2xl bg-secondary p-3 min-w-0">
            <div className="flex h-[38px] w-[38px] items-center justify-center rounded-full bg-[#ffe0cb] text-lg shrink-0">🩺</div>
            <div className="min-w-0">
              <strong className="block truncate text-[13px]">Hey, {name}!</strong>
              <small className="block truncate text-muted-foreground">{planLabel}{year ? ` • ${year}` : ""}</small>
            </div>
          </Link>
        )}
      </SidebarHeader>

      <SidebarContent className="gap-0">
        {isAdmin && (
          <SidebarGroup>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={pathname === "/admin"} tooltip="Admin" className={ITEM + " border border-primary/20 bg-primary/5"}>
                    <Link href="/admin" onClick={closeOnMobile}>
                      <CloudUpload className="h-[18px] w-[18px]" />
                      <span>Content Manager</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={pathname.startsWith("/prof-pyq")} tooltip="Prof PYQ (hidden from users)" className={ITEM + " border border-dashed border-yellow-500/30"}>
                    <Link href="/prof-pyq" onClick={closeOnMobile}>
                      <GraduationCap className="h-[18px] w-[18px]" />
                      <span>Prof PYQ (admin only)</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        <SidebarGroup>
          {label("Home")}
          <SidebarGroupContent>
            <SidebarMenu>
              {home.map(row)}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          {label("Notes")}
          <SidebarGroupContent>
            <SidebarMenu>
              {notes.map(row)}
              <QuickCardsMenuItems pathname={pathname} onNavigate={closeOnMobile} />
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          {label("QBank")}
          <SidebarGroupContent>
            <SidebarMenu>
              {qbank.map(row)}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          {label("Test")}
          <SidebarGroupContent>
            <SidebarMenu>
              {tests.map(row)}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          {label("Bedside")}
          <SidebarGroupContent>
            <SidebarMenu>
              {bedside.slice(0, 1).map(row)}
              <CasePresentationMenuItem pathname={pathname} onNavigate={closeOnMobile} />
              {bedside.slice(1).map(row)}
              {stories.map(row)}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          {label("AI Studio")}
          <SidebarGroupContent>
            <SidebarMenu>{studio.map(row)}</SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          {label("Account")}
          <SidebarGroupContent>
            <SidebarMenu>{account.map(row)}</SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      {isFree && (
        <SidebarFooter className="p-4">
          <div className="rounded-[18px] bg-[#fff0df] p-4">
            <div className="text-[28px] leading-none">🌟</div>
            <b className="mt-1 block text-sm text-[#382316]">Make your next leap</b>
            <p className="my-1 mb-3 text-xs text-[#80674f]">Unlock every note, quiz, case and Jelly session.</p>
            <Link href="/pricing" onClick={closeOnMobile} className="block w-full rounded-xl bg-[#292333] px-3 py-2.5 text-center text-[13px] font-extrabold text-white">
              Explore Scholar · ₹999/yr
            </Link>
          </div>
        </SidebarFooter>
      )}
    </Sidebar>
  )
}
