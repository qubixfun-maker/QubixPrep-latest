"use client"
import { useTopSearch } from "@/components/layout/top-search"

import Link from "next/link"
import { useState } from "react"
import { ArrowLeft, ChevronRight, ClipboardList, FileText, Loader2, Trash2, Stethoscope, Lock, GraduationCap } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useFirestore } from "@/firebase"
import { SUBJECTS, ALL_CASES, getCase, casesFor } from "@/lib/casepres"
import { useCaseAccess, useMyCaseSheets, deleteCaseSheet } from "@/hooks/use-case-sheets"

export default function CasePresentationHub() {
  const { user, allowed, loading } = useCaseAccess()
  const { sheets, loading: sheetsLoading } = useMyCaseSheets()
  const db = useFirestore()
  // first the student chooses what they want; only then does the next screen open
  const [view, setView] = useState<"proforma" | "sample" | null>(null)
  const [open, setOpen] = useState<string | null>(null)
  const [search] = useTopSearch("Search cases…")
  const q = search.trim().toLowerCase()

  if (loading) return <div className="flex justify-center py-24"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>

  const remove = async (id: string) => {
    if (!db || !user) return
    if (!window.confirm("Delete this saved case?")) return
    await deleteCaseSheet(db, user.uid, id)
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Case <span className="text-accent">Presentation</span></h1>
        <p className="text-sm text-muted-foreground mt-1 max-w-2xl">
          {view === null
            ? "What would you like to do?"
            : view === "proforma"
              ? "Pick a subject, then a proforma. Tap the options that apply, type anything extra, then press Present case for a professional write-up."
              : "Pick a subject, then a ready-made case to learn from."}
        </p>
        {!allowed && (
          <div className="mt-4 rounded-2xl border border-accent/30 bg-accent/10 p-4 flex items-center gap-3 flex-wrap">
            <Lock className="h-5 w-5 text-accent" />
            <div className="text-sm flex-1 min-w-[200px]">Case Presentation is available to subscribers. Scholar is ₹999/year.</div>
            <Link href="/pricing"><Button size="sm">View plans</Button></Link>
          </div>
        )}
      </div>

      {view === null && !q && (
        <div className="grid gap-4 sm:grid-cols-2">
          {([
            { k: "proforma" as const, icon: ClipboardList, title: "Case proformas", desc: "The blank college proformas for each subject. Fill in your own patient and present the case.", n: ALL_CASES.filter((c) => c.kind === "proforma").length, unit: "proformas", grad: "from-indigo-500 to-violet-600" },
            { k: "sample" as const, icon: GraduationCap, title: "Sample cases", desc: "Ready-made cases on common topics, with an exam checklist, viva questions and a model presentation.", n: ALL_CASES.filter((c) => c.kind === "sample").length, unit: "cases", grad: "from-emerald-500 to-teal-600" },
          ]).map((o) => (
            <button key={o.k} onClick={() => { setView(o.k); setOpen(`${o.k}:medicine`); window.scrollTo({ top: 0 }) }}
              className={`group relative flex min-h-[11rem] flex-col justify-end overflow-hidden rounded-3xl bg-gradient-to-br ${o.grad} p-6 text-left text-white shadow-md transition active:scale-[0.98] hover:shadow-xl`}>
              <o.icon className="absolute -right-4 -top-4 h-32 w-32 rotate-12 opacity-20" />
              <o.icon className="absolute right-5 top-5 h-10 w-10 opacity-90" />
              <span className="text-2xl font-extrabold leading-tight">{o.title}</span>
              <span className="mt-1 text-sm opacity-90">{o.desc}</span>
              <span className="mt-2 text-xs font-bold opacity-90">{o.n} {o.unit}</span>
            </button>
          ))}
        </div>
      )}

      {view !== null && !q && (
        <button onClick={() => { setView(null); setOpen(null) }} className="inline-flex items-center gap-1 text-sm font-bold text-muted-foreground hover:text-foreground"><ArrowLeft className="h-4 w-4" /> Back</button>
      )}

      {user && allowed && view !== null && (
        <section className="space-y-3">
          <h2 className="text-lg font-bold">My saved cases</h2>
          {sheetsLoading ? <Loader2 className="h-5 w-5 animate-spin text-primary" /> : sheets.filter((s) => getCase(s.caseType)?.kind === view).length === 0 ? (
            <p className="text-sm text-muted-foreground">Nothing saved yet. Start a case below: it saves automatically.</p>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2">
              {sheets.filter((s) => getCase(s.caseType)?.kind === view).map((s) => {
                const c = getCase(s.caseType)
                return (
                  <div key={s.id} className="glass rounded-2xl border border-white/10 p-4 flex items-center gap-3">
                    <Link href={`/case-presentation/${s.caseType}/${s.id}`} className="flex-1 min-w-0">
                      <div className="font-semibold truncate">{s.title || "Untitled case"}</div>
                      <div className="text-xs text-muted-foreground truncate">{c?.title ?? s.caseType}{s.updatedAt?.toDate ? ` · ${s.updatedAt.toDate().toLocaleDateString()}` : ""}</div>
                    </Link>
                    <button onClick={() => remove(s.id)} className="p-2 text-muted-foreground hover:text-destructive" aria-label="Delete"><Trash2 className="h-4 w-4" /></button>
                  </div>
                )
              })}
            </div>
          )}
        </section>
      )}

      {(view ? [view] : q ? (["proforma", "sample"] as const) : []).map((kind) => (
        <section key={kind} className="space-y-3">
          <div>
            <h2 className="text-lg font-bold">{kind === "proforma" ? "Proformas" : "Sample cases"}</h2>
            <p className="text-xs text-muted-foreground mt-0.5 max-w-2xl">
              {kind === "proforma"
                ? "The blank college proformas for each subject. Fill in your own patient."
                : "Ready-made cases on common topics, each with a topic checklist, exam checklist, viva questions and a model case presentation to learn from."}
            </p>
          </div>
          <div className="space-y-3">
            {SUBJECTS.map((s) => {
              const cases = casesFor(s.id, kind).filter((c) => !q || `${c.title} ${c.blurb}`.toLowerCase().includes(q))
              if (cases.length === 0) return null
              const key = `${kind}:${s.id}`
              const isOpen = !!q || open === key
              return (
                <div key={key} className="glass rounded-3xl border border-white/10 overflow-hidden">
                  <button onClick={() => setOpen(isOpen ? null : key)} className="w-full flex items-center gap-3 p-5 text-left">
                    <div className="p-3 rounded-2xl bg-primary/10 text-primary"><Stethoscope className="h-5 w-5" /></div>
                    <div className="flex-1 min-w-0">
                      <div className="font-bold">{s.name}</div>
                      <div className="text-xs text-muted-foreground">{s.blurb}</div>
                    </div>
                    <Badge variant="outline">{cases.length} {kind === "proforma" ? (cases.length === 1 ? "proforma" : "proformas") : (cases.length === 1 ? "case" : "cases")}</Badge>
                    <ChevronRight className={`h-5 w-5 text-muted-foreground transition-transform ${isOpen ? "rotate-90" : ""}`} />
                  </button>
                  {isOpen && (
                    <div className="grid gap-2 sm:grid-cols-2 p-4 pt-0">
                      {cases.map((c) => (
                        <Link key={c.id} href={`/case-presentation/${c.id}/new`} className="rounded-2xl border border-white/10 p-4 hover:border-primary/50 transition-colors flex items-start gap-3">
                          <FileText className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                          <div className="min-w-0">
                            <div className="font-semibold leading-tight">{c.title}</div>
                            <div className="text-xs text-muted-foreground mt-1">{c.blurb}</div>
                          </div>
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </section>
      ))}
      {view === null && !q && <p className="text-xs text-muted-foreground">{ALL_CASES.filter((c) => c.kind === "proforma").length} proformas and {ALL_CASES.filter((c) => c.kind === "sample").length} sample cases across {SUBJECTS.length} subjects.</p>}
    </div>
  )
}
