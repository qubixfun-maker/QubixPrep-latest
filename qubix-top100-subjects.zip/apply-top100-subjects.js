const fs = require("fs"), path = require("path")
const target = path.join("src", "app", "top-100", "page.tsx")
if (!fs.existsSync(target)) { console.error("Not found: " + target + " (run from the project root). Nothing changed."); process.exit(1) }
const cur = fs.readFileSync(target, "utf8")
if (cur.includes("SUBJECT_STYLE")) { console.log("Already applied."); process.exit(0) }
if (!cur.includes("loadTop100List")) { console.error("This is not the new Top 100 page. Nothing changed."); process.exit(1) }
fs.copyFileSync(path.join(__dirname, "src", "app", "top-100", "page.tsx"), target)
console.log("Done: Top 100 now opens with big subject buttons.")
