'use server';
import { callAI } from '@/ai/genkit';

export type TextbookSource = {
  textbookTitle: string;
  chapterTitle: string;
  text: string;
};

export type GenerateFromTextbookInput = {
  sources: TextbookSource[];
  questionsRaw: string;
  subject: string;
  chapter: string;
  sectionType: 'long-essays' | 'short-essays' | 'short-answers';
};

export type GenerateFromTextbookOutput = {
  html: string;
  error?: string;
};

// Rough safety cap so we don't blow past a reasonable prompt size across multiple sources
const MAX_CHARS_PER_SOURCE = 60000;

function buildPrompt(input: GenerateFromTextbookInput): string {
  const sectionLabel = input.sectionType === 'long-essays' ? 'Long Essay' : input.sectionType === 'short-essays' ? 'Short Essay' : 'Short Answer';

  const sourcesBlock = input.sources.map((s, i) => {
    const truncated = s.text.length > MAX_CHARS_PER_SOURCE ? s.text.slice(0, MAX_CHARS_PER_SOURCE) + '\n[...excerpt truncated...]' : s.text;
    return `--- SOURCE ${i + 1}: "${s.textbookTitle}", Chapter: "${s.chapterTitle}" ---\n${truncated}`;
  }).join('\n\n');

  return `You are answering exam questions strictly using the textbook excerpt(s) provided below - you must NOT use any outside knowledge, even if you know more about the topic from your own training. If the excerpts don't contain enough information to fully answer a question, answer as completely as the excerpts allow and note briefly that the source material doesn't cover certain aspects, rather than filling gaps from memory.

Subject: ${input.subject}
Chapter: ${input.chapter}
Section: ${sectionLabel}

TEXTBOOK EXCERPT(S):
${sourcesBlock}

QUESTIONS TO ANSWER (answer ALL of them, in order):
${input.questionsRaw}

TASK:
1. Write a THOROUGH, exam-topper-quality answer, not a brief summary - mine the excerpt for every mechanism, sub-type, named process, and example relevant to the question, using ONLY facts present in the excerpt(s) above. A real top-scoring student writes named, individually-explained points (e.g. explain WHY each step happens, not just that it happens), not a compressed one-line version of the same content. If the excerpt covers related sub-topics that a complete answer to this question should include (e.g. specific named mechanisms, subtypes, or examples), include all of them - do not stop at a minimal answer when the excerpt has more relevant material available.

NEVER reference the source in the answer text itself. Do not write "the excerpt states", "the source material outlines", "according to the textbook", "the passage describes", or any similar phrase. A real student writing an exam answer states facts directly and confidently as their own knowledge - e.g. write "ATP depletion causes..." not "The source material explains that ATP depletion causes...". This applies to every sentence in the answer, not just the opening line.
2. Organize each answer into clean HTML using headings (h4), paragraphs (p), lists (ul/ol), and TABLES where the content naturally has structure. If the excerpt presents information as a comparison, classification, or side-by-side listing (e.g. "Table 3.2: Classification of..."), reproduce it as a proper HTML table using <table><thead><tr><th>...</th></tr></thead><tbody><tr><td>...</td></tr></tbody></table> - preserve the actual rows and columns from the source, do not flatten a table into a plain list.
3. MECHANISM CHAINS: when the excerpt describes a cause-and-effect sequence (e.g. "decreased ATP leads to pump failure, causing sodium accumulation"), write it as a single flowing sentence wrapped in <p class="qa-chain">, with the key terms in <strong> tags connected by plain arrow characters. The qa-chain class makes each bolded term render as a connected colored box, giving a genuine visual flowchart from plain text - always include class="qa-chain" on the wrapping <p> for any mechanism chain, e.g.:
<p class="qa-chain"><strong>&darr;ATP</strong> &rarr; <strong>pump failure</strong> &rarr; intracellular Na+ accumulates, K+ is lost &rarr; <strong>cellular swelling</strong></p>
Only do this for a genuine short chain (2-6 linked steps) - if the excerpt describes several independent/parallel effects branching from one cause rather than one strict line, present those as a normal list instead, each with its own bolded key term. After each arrow-chain or list item, if the excerpt explains WHY that step occurs or gives supporting detail (a mechanism, a reason, a specific example), include that explanation as following prose or as a sub-bullet - do not leave the chain as bare labels with no explanation when the excerpt provides more detail than that.

4. CLASSIFICATION TREES: when the excerpt classifies something into categories and sub-categories (e.g. "cell injury is either reversible or irreversible; irreversible injury includes necrosis and apoptosis"), render it as a tree instead of nested lists:
<div class="qa-tree">
  <div class="qa-tree-node">Top-level term</div>
  <div class="qa-tree-branch">
    <div class="qa-tree-child">
      <div class="qa-tree-node">Category A</div>
      <div class="qa-tree-desc">One-line description if the source gives one</div>
    </div>
    <div class="qa-tree-child">
      <div class="qa-tree-node">Category B</div>
      <div class="qa-tree-desc">One-line description if the source gives one</div>
    </div>
  </div>
</div>
A qa-tree-child can itself contain a nested qa-tree-branch if the source describes a further level of sub-classification. Only use this for genuine is-a/type-of classification hierarchies explicitly stated in the source - do not invent categories not present in the excerpt.

NO DUPLICATION: pick exactly ONE format for each piece of classification content - never restate the same categories twice (e.g. once as plain paragraphs AND again as a table, or once as a tree AND again as a table). If the source presents something as a table (has clear columns/rows, like "Mechanism | Nomenclature"), output ONLY the table for that content - do not also write it out as prose or a tree first. Use a tree only for classification content that is NOT already presented as a table in the source.

5. SUMMARY CALLOUT: if the excerpt's discussion of a mechanism ends with (or the topic naturally supports) a single overall summary sentence tying the mechanism together, you may add ONE such sentence at the end wrapped as:
<div class="qa-callout">Summary sentence here, using only what the excerpt already established - do not add new facts.</div>
Only include this when it genuinely helps tie together a longer mechanism - skip it for short/simple answers.
6. If a question in the input has a repeat-frequency bracket like "[asked 3x: 2015, 2018, 2022]", extract it into a separate qa-repeat span and remove the bracket text from the visible question.
7. Number the questions sequentially starting from 1.
8. Output ONLY the following HTML structure, repeated for each question - no markdown fences, no commentary:

<div class="qa-item">
  <div class="qa-question">
    <span class="qa-number">1.</span>
    Question text here
    <span class="qa-repeat">Asked 3 times - 2015, 2018, 2022</span>
  </div>
  <div class="qa-answer">
    <h4>Section heading if applicable</h4>
    <p>...</p>
  </div>
</div>

Output raw HTML only. No markdown fences. No preamble or closing remarks.`
}

export async function generateFromTextbook(input: GenerateFromTextbookInput): Promise<GenerateFromTextbookOutput> {
  if (!input.questionsRaw.trim()) {
    return { html: '', error: 'No questions provided.' }
  }
  if (!input.sources.length) {
    return { html: '', error: 'No textbook source excerpts provided.' }
  }

  try {
    const prompt = buildPrompt(input)
    const raw = await callAI([{ role: 'user', content: prompt }], 8000)
    if (!raw) return { html: '', error: 'Empty response from AI model' }

    let clean = raw.replace(/```html|```/g, '').trim()

    if (!clean.includes('qa-item')) {
      return { html: '', error: 'AI response did not contain the expected qa-item structure. Try again, or try fewer questions per batch.' }
    }

    return { html: clean }
  } catch (err: any) {
    return { html: '', error: err.message || 'Unknown error during generation' }
  }
}
