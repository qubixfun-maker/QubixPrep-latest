
"use client"

import { useMemo, useState, useEffect, useRef } from "react"
import { useUser, useDoc, useFirestore, useCollection, useStorage } from "@/firebase"
import { ref as storageRef, uploadBytes, deleteObject } from "firebase/storage"
import { doc, collection, query, orderBy, increment, updateDoc, deleteDoc, getDocs, getDoc, setDoc, writeBatch } from "firebase/firestore"
import { supabase } from "@/lib/supabase"
import { groupByUnit } from "@/lib/unit-sort"
import { generateClinicalCase, ClinicalCase } from "@/ai/flows/ai-case-generator"
import { CASE_TOPICS } from "@/ai/case-topics"
import { generateProfPyqAnswer } from "@/ai/flows/ai-profpyq-answer-generator"
import { generateBannerCopy } from "@/ai/flows/ai-banner-generator"
import Papa from "papaparse"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { 
  ShieldAlert,
  Loader2,
  Lock,
  FileText,
  Network,
  Database,
  Plus,
  Trash2,
  ChevronRight,
  BookOpen,
  Layout,
  RefreshCw,
  Video,
  X,
  Upload,
  Layers,
  HelpCircle,
  Edit2,
  FileDown,
  AlertTriangle,
  Trophy,
  ShoppingBag,
  GripVertical,
  ChevronUp,
  ChevronDown,
  CheckCircle2,
  Wand2,
  Users,
  BookMarked,
  BarChart3,
  Sparkles,
  ArrowRight,
  Gift,
  Zap,
  BookOpenText,
  Stethoscope,
  Flame
} from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import Link from "next/link"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"

export default function AdminDashboard() {
  const { user, loading: authLoading } = useUser()
  const db = useFirestore()
  const storage = useStorage()
  const { toast } = useToast()
  
  const [activeSubject, setActiveSubject] = useState<string | null>(null)
  const [isAssigningUnit, setIsAssigningUnit] = useState(false)
  const [useAiFixer, setUseAiFixer] = useState(true)
  const [subjectContent, setSubjectContent] = useState<{
    topics: any[],
    mindmaps: any[],
    questions: any[]
  }>({ topics: [], mindmaps: [], questions: [] })
  
  const [isAddingTopic, setIsAddingTopic] = useState(false)
  const [isAddingVideo, setIsAddingVideo] = useState(false)
  const [isAddingMindmap, setIsAddingMindmap] = useState(false)
  const [isUploadingQBank, setIsUploadingQBank] = useState(false)
  const [isEditingQuestion, setIsEditingQuestion] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [loadingContent, setLoadingContent] = useState(false)
  const [isUploadingPYQ, setIsUploadingPYQ] = useState(false)
  const [pyqQuestions, setPyqQuestions] = useState<any[]>([])
  const [loadingPYQ, setLoadingPYQ] = useState(false)
  const [pyqSearch, setPyqSearch] = useState("")
  const [pyqExamFilter, setPyqExamFilter] = useState("All")
  const [pyqYearFilter, setPyqYearFilter] = useState("All")
  const [editingPYQId, setEditingPYQId] = useState<string | null>(null)
  const [pyqBulkExam, setPyqBulkExam] = useState("NEET PG")
  const [pyqBulkYear, setPyqBulkYear] = useState(new Date().getFullYear().toString())
  const [pyqAiSubjectFix, setPyqAiSubjectFix] = useState(true)
  const [pyqForm, setPyqForm] = useState({
    exam_type: "NEET PG",
    year: new Date().getFullYear().toString(),
    subject: "",
    question_text: "",
    option1: "",
    option2: "",
    option3: "",
    option4: "",
    correct_answer_index: "0",
    explanation: ""
  })
  const [isAddingProduct, setIsAddingProduct] = useState(false)
  const [csvParsedTopics, setCsvParsedTopics] = useState<{topicName: string, unitName: string, questions: any[], order: number}[]>([])
  const [csvUnitName, setCsvUnitName] = useState("")
  const [showCsvOrganizer, setShowCsvOrganizer] = useState(false)
  const [selectedCsvTopics, setSelectedCsvTopics] = useState<Set<number>>(new Set())
  const [bulkUnitInput, setBulkUnitInput] = useState("")
  const [aiFixing, setAiFixing] = useState(false)
  const [aiFixLog, setAiFixLog] = useState<{row: number, field: string, before: string, after: string}[]>([])
  const [showFixLog, setShowFixLog] = useState(false)
  const [reassignTopic, setReassignTopic] = useState<{topic: string, currentUnit: string} | null>(null)
  const [reassignUnitInput, setReassignUnitInput] = useState("")
  const [reassigning, setReassigning] = useState(false)
  const [aiFixProgress, setAiFixProgress] = useState({ done: 0, total: 0, message: "" })
  const [productForm, setProductForm] = useState({
    title: "", description: "", price: "",
    category: "Notes Pack", buy_link: "", image_url: ""
  })
  
  const [topicForm, setTopicForm] = useState({
    subjectId: "",
    unitName: "",
    title: "",
    importance: "Medium" as "Low" | "Medium" | "High" | "Essential",
    tier: "free" as "free" | "paid",
    file: null as File | null
  })

  const [videoForm, setVideoForm] = useState({
    subjectId: "",
    unitName: "",
    title: "",
    url: "",
    importance: "Medium" as "Low" | "Medium" | "High" | "Essential",
    tier: "free" as "free" | "paid"
  })

  const [mindmapForm, setMindmapForm] = useState({
    subjectId: "",
    unitName: "",
    title: "",
    tier: "free" as "free" | "paid",
    file: null as File | null
  })

  const [isManagingCases, setIsManagingCases] = useState(false)
  const [allCases, setAllCases] = useState<any[]>([])
  const [batchRun, setBatchRun] = useState<{ done: number; total: number; failed: number; running: boolean } | null>(null)
  const batchStopRef = useRef(false)
  const [loadingCases, setLoadingCases] = useState(false)
  const [caseGenSpecialty, setCaseGenSpecialty] = useState("")
  const [caseGenTopic, setCaseGenTopic] = useState("")
  const [caseGenDifficulty, setCaseGenDifficulty] = useState<"easy" | "medium" | "hard">("medium")
  const [caseGenTier, setCaseGenTier] = useState<"free" | "paid">("free")
  const [generatingCase, setGeneratingCase] = useState(false)
  const [draftCase, setDraftCase] = useState<ClinicalCase | null>(null)
  const [savingCase, setSavingCase] = useState(false)

  async function fetchAllCases() {
    if (!db) return
    setLoadingCases(true)
    try {
      const snap = await getDocs(collection(db, 'cases'))
      setAllCases(snap.docs.map(d => ({ ...d.data(), id: d.id })))
    } catch (e: any) {
      toast({ variant: "destructive", title: "Failed to load cases", description: e.message })
    } finally {
      setLoadingCases(false)
    }
  }

  const [isManagingBanner, setIsManagingBanner] = useState(false)
  const [loadingBanner, setLoadingBanner] = useState(false)
  const [savingBanner, setSavingBanner] = useState(false)
  const [generatingBanner, setGeneratingBanner] = useState(false)
  const [bannerGenPrompt, setBannerGenPrompt] = useState("")
  const [allBanners, setAllBanners] = useState<any[]>([])
  const emptyBannerForm = {
    id: null as string | null,
    enabled: true,
    badgeText: "",
    headline: "",
    headlineHighlight: "",
    bullets: ["", "", ""] as string[],
    buttonText: "",
    buttonLink: "/products"
  }
  const [bannerForm, setBannerForm] = useState(emptyBannerForm)

  async function fetchBanners() {
    if (!db) return
    setLoadingBanner(true)
    try {
      const snap = await getDocs(collection(db, "dashboardBanners"))
      const list = snap.docs.map(d => ({ ...d.data(), id: d.id }))
      list.sort((a: any, b: any) => (a.order ?? 0) - (b.order ?? 0))
      setAllBanners(list)
    } catch (e: any) {
      toast({ variant: "destructive", title: "Failed to load ads", description: e.message })
    } finally {
      setLoadingBanner(false)
    }
  }

  async function handleGenerateBannerAI() {
    if (!bannerGenPrompt.trim()) {
      toast({ variant: "destructive", title: "Describe what to advertise first" })
      return
    }
    setGeneratingBanner(true)
    try {
      const result = await generateBannerCopy({ prompt: bannerGenPrompt.trim() })
      if (result.error || !result.draft) throw new Error(result.error || "No draft returned")
      setBannerForm((f) => ({
        ...f,
        badgeText: result.draft!.badgeText,
        headline: result.draft!.headline,
        headlineHighlight: result.draft!.headlineHighlight,
        bullets: result.draft!.bullets,
        buttonText: result.draft!.buttonText
      }))
    } catch (e: any) {
      toast({ variant: "destructive", title: "AI Draft Failed", description: e.message })
    } finally {
      setGeneratingBanner(false)
    }
  }

  async function handleSaveBanner() {
    if (!db) return
    if (!bannerForm.headline.trim()) {
      toast({ variant: "destructive", title: "Enter a headline first" })
      return
    }
    setSavingBanner(true)
    try {
      const id = bannerForm.id || `banner-${Date.now()}`
      await setDoc(doc(db, "dashboardBanners", id), {
        id,
        enabled: bannerForm.enabled,
        badgeText: bannerForm.badgeText,
        headline: bannerForm.headline,
        headlineHighlight: bannerForm.headlineHighlight,
        bullets: bannerForm.bullets,
        buttonText: bannerForm.buttonText,
        buttonLink: bannerForm.buttonLink,
        order: bannerForm.id ? undefined : Date.now(),
        updatedAt: new Date().toISOString()
      }, { merge: true })
      toast({ title: bannerForm.id ? "Ad Updated" : "Ad Created" })
      setBannerForm(emptyBannerForm)
      fetchBanners()
    } catch (e: any) {
      toast({ variant: "destructive", title: "Save Failed", description: e.message })
    } finally {
      setSavingBanner(false)
    }
  }

  function handleEditBanner(item: any) {
    setBannerForm({
      id: item.id,
      enabled: item.enabled !== false,
      badgeText: item.badgeText || "",
      headline: item.headline || "",
      headlineHighlight: item.headlineHighlight || "",
      bullets: item.bullets && item.bullets.length === 3 ? item.bullets : ["", "", ""],
      buttonText: item.buttonText || "",
      buttonLink: item.buttonLink || "/products"
    })
  }

  async function handleDeleteBanner(item: any) {
    if (!db || !confirm(`Delete ad "${item.headline}"?`)) return
    try {
      await deleteDoc(doc(db, "dashboardBanners", item.id))
      toast({ title: "Ad Deleted" })
      fetchBanners()
    } catch (e: any) {
      toast({ variant: "destructive", title: "Delete Failed", description: e.message })
    }
  }

  async function handleToggleBannerEnabled(item: any) {
    if (!db) return
    try {
      await updateDoc(doc(db, "dashboardBanners", item.id), { enabled: !item.enabled })
      fetchBanners()
    } catch (e: any) {
      toast({ variant: "destructive", title: "Update Failed", description: e.message })
    }
  }

    const [isManagingNotePacks, setIsManagingNotePacks] = useState(false)
  const [allNotePacks, setAllNotePacks] = useState<any[]>([])
  const [loadingNotePacks, setLoadingNotePacks] = useState(false)
  const [uploadingNotePack, setUploadingNotePack] = useState(false)
  const [notePackForm, setNotePackForm] = useState({
    id: null as string | null,
    packType: "single" as "single" | "combo",
    year: "1st" as "1st" | "2nd" | "3rd",
    title: "",
    description: "",
    price: "149",
    file: null as File | null,
    includedPackIds: [] as string[]
  })
  const emptyNotePackForm = { id: null as string | null, packType: "single" as "single" | "combo", year: "1st" as "1st" | "2nd" | "3rd", title: "", description: "", price: "149", file: null as File | null, includedPackIds: [] as string[] }

  async function fetchAllNotePacks() {
    if (!db) return
    setLoadingNotePacks(true)
    try {
      const snap = await getDocs(collection(db, "notePacks"))
      setAllNotePacks(snap.docs.map(d => ({ ...d.data(), id: d.id })))
    } catch (e: any) {
      toast({ variant: "destructive", title: "Failed to load Notes Packs", description: e.message })
    } finally {
      setLoadingNotePacks(false)
    }
  }

  async function handleSaveNotePack() {
    if (!db || !storage || !notePackForm.title.trim()) {
      toast({ variant: "destructive", title: "Enter a title first" })
      return
    }
    if (notePackForm.packType === "single" && !notePackForm.id && !notePackForm.file) {
      toast({ variant: "destructive", title: "Select a PDF file to upload" })
      return
    }
    if (notePackForm.packType === "combo" && notePackForm.includedPackIds.length < 2) {
      toast({ variant: "destructive", title: "Select at least 2 packs to bundle" })
      return
    }
    setUploadingNotePack(true)
    try {
      const id = notePackForm.id || `notepack-${Date.now()}`
      let storagePath = (notePackForm as any).existingStoragePath || null

      if (notePackForm.packType === "single" && notePackForm.file) {
        storagePath = `notepacks-private/${id}.pdf`
        const fileRef = storageRef(storage, storagePath)
        await uploadBytes(fileRef, notePackForm.file, { contentType: "application/pdf" })
      }

      await setDoc(doc(db, "notePacks", id), {
        id,
        packType: notePackForm.packType,
        year: notePackForm.packType === "single" ? notePackForm.year : null,
        title: notePackForm.title.trim(),
        description: notePackForm.description.trim(),
        price: Number(notePackForm.price) || 149,
        storagePath: notePackForm.packType === "single" ? storagePath : null,
        includedPackIds: notePackForm.packType === "combo" ? notePackForm.includedPackIds : [],
        active: true,
        order: notePackForm.id ? undefined : Date.now(),
        createdAt: new Date().toISOString()
      }, { merge: true })

      toast({ title: notePackForm.id ? "Notes Pack Updated" : "Notes Pack Created" })
      setNotePackForm(emptyNotePackForm)
      fetchAllNotePacks()
    } catch (e: any) {
      toast({ variant: "destructive", title: "Save Failed", description: e.message })
    } finally {
      setUploadingNotePack(false)
    }
  }

  function handleEditNotePack(item: any) {
    setNotePackForm({
      id: item.id,
      packType: item.packType || "single",
      year: item.year || "1st",
      title: item.title || "",
      description: item.description || "",
      price: String(item.price || 149),
      file: null,
      includedPackIds: item.includedPackIds || [],
      ...( { existingStoragePath: item.storagePath } as any )
    })
  }

  async function handleDeleteNotePack(item: any) {
    if (!db) return

    const usedInCombos = allNotePacks.filter((p: any) => p.packType === "combo" && Array.isArray(p.includedPackIds) && p.includedPackIds.includes(item.id))
    if (usedInCombos.length > 0) {
      const comboNames = usedInCombos.map((c: any) => c.title).join(", ")
      if (!confirm(`WARNING: "${item.title}" is used inside these combo(s): ${comboNames}. Deleting it will break those combos for anyone who bought them. Delete anyway?`)) return
    } else {
      if (!confirm(`Delete "${item.title}"? Students who already bought it will lose access.`)) return
    }

    try {
      await deleteDoc(doc(db, "notePacks", item.id))
      if (storage && item.storagePath) {
        try { await deleteObject(storageRef(storage, item.storagePath)) } catch (e) { /* file may already be gone, ignore */ }
      }
      toast({ title: "Notes Pack Deleted" })
      fetchAllNotePacks()
    } catch (e: any) {
      toast({ variant: "destructive", title: "Delete Failed", description: e.message })
    }
  }

  const [isManagingProfPyq, setIsManagingProfPyq] = useState(false)
  const [allProfPyq, setAllProfPyq] = useState<any[]>([])
  const [loadingProfPyq, setLoadingProfPyq] = useState(false)
  const [generatingProfAnswer, setGeneratingProfAnswer] = useState(false)
  const [savingProfPyq, setSavingProfPyq] = useState(false)
  const [uploadingProfPyqCsv, setUploadingProfPyqCsv] = useState(false)
  const [profPyqForm, setProfPyqForm] = useState({
    id: null as string | null,
    subject: "",
    chapter: "",
    type: "short_answer" as "short_answer" | "short_essay" | "long_answer",
    question: "",
    answer: "",
    tier: "free" as "free" | "paid"
  })

  async function fetchAllProfPyq() {
    if (!db) return
    setLoadingProfPyq(true)
    try {
      const snap = await getDocs(collection(db, 'profpyq'))
      setAllProfPyq(snap.docs.map(d => ({ ...d.data(), id: d.id })))
    } catch (e: any) {
      toast({ variant: "destructive", title: "Failed to load Prof PYQ", description: e.message })
    } finally {
      setLoadingProfPyq(false)
    }
  }

  async function handleGenerateProfAnswer() {
    if (!profPyqForm.subject.trim() || !profPyqForm.chapter.trim() || !profPyqForm.question.trim()) {
      toast({ variant: "destructive", title: "Enter subject, chapter and question first" })
      return
    }
    setGeneratingProfAnswer(true)
    try {
      const result = await generateProfPyqAnswer({
        subject: profPyqForm.subject.trim(),
        chapter: profPyqForm.chapter.trim(),
        type: profPyqForm.type,
        question: profPyqForm.question.trim()
      })
      if (result.error || !result.answer) throw new Error(result.error || "No answer returned")
      setProfPyqForm((f) => ({ ...f, answer: result.answer! }))
    } catch (e: any) {
      toast({ variant: "destructive", title: "AI Assist Failed", description: e.message })
    } finally {
      setGeneratingProfAnswer(false)
    }
  }

  async function handleSaveProfPyq() {
    if (!db || !profPyqForm.subject.trim() || !profPyqForm.chapter.trim() || !profPyqForm.question.trim() || !profPyqForm.answer.trim()) {
      toast({ variant: "destructive", title: "Fill in subject, chapter, question and answer" })
      return
    }
    setSavingProfPyq(true)
    try {
      const id = profPyqForm.id || `profpyq-${Date.now()}`
      await setDoc(doc(db, 'profpyq', id), {
        id,
        subject: profPyqForm.subject.trim(),
        chapter: profPyqForm.chapter.trim(),
        type: profPyqForm.type,
        question: profPyqForm.question.trim(),
        answer: profPyqForm.answer.trim(),
        tier: profPyqForm.tier,
        order: profPyqForm.id ? undefined : Date.now(),
        createdAt: new Date().toISOString()
      }, { merge: true })
      toast({ title: profPyqForm.id ? "Question Updated" : "Question Added" })
      setProfPyqForm({ id: null, subject: profPyqForm.subject, chapter: profPyqForm.chapter, type: profPyqForm.type, question: "", answer: "", tier: "free" })
      fetchAllProfPyq()
    } catch (e: any) {
      toast({ variant: "destructive", title: "Save Failed", description: e.message })
    } finally {
      setSavingProfPyq(false)
    }
  }

  function handleEditProfPyq(item: any) {
    setProfPyqForm({
      id: item.id,
      subject: item.subject || "",
      chapter: item.chapter || "",
      type: item.type || "short_answer",
      question: item.question || "",
      answer: item.answer || "",
      tier: item.tier || "free"
    })
  }

  async function handleDeleteProfPyq(item: any) {
    if (!db || !confirm("Delete this question?")) return
    try {
      await deleteDoc(doc(db, 'profpyq', item.id))
      toast({ title: "Question Deleted" })
      fetchAllProfPyq()
    } catch (e: any) {
      toast({ variant: "destructive", title: "Delete Failed", description: e.message })
    }
  }

  async function handleBulkImportProfPyq(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file || !db) return
    setUploadingProfPyqCsv(true)
    Papa.parse(file, {
      header: false,
      skipEmptyLines: true,
      complete: async (results) => {
        try {
          const rows = (results.data as string[][]).slice(1)
          const batch = writeBatch(db)
          let count = 0
          rows.forEach((parts) => {
            if (!parts || parts.length < 5 || !parts[3] || !parts[4]) return
            const id = `profpyq-${Date.now()}-${count}`
            const ref = doc(db, 'profpyq', id)
            batch.set(ref, {
              id,
              subject: parts[0]?.trim() || "",
              chapter: parts[1]?.trim() || "",
              type: (parts[2]?.trim() as any) || "short_answer",
              question: parts[3]?.trim(),
              answer: parts[4]?.trim(),
              tier: (parts[5]?.trim() as any) || "free",
              order: Date.now() + count,
              createdAt: new Date().toISOString()
            })
            count++
          })
          await batch.commit()
          toast({ title: "Import Complete", description: count + " questions imported." })
          fetchAllProfPyq()
        } catch (err: any) {
          toast({ variant: "destructive", title: "Import Failed", description: err.message })
        } finally {
          setUploadingProfPyqCsv(false)
          e.target.value = ""
        }
      }
    })
  }

  const [qbankForm, setQbankForm] = useState({
    id: null as number | null,
    subjectId: "",
    unit_title: "",
    topic_title: "",
    question_text: "",
    option1: "",
    option2: "",
    option3: "",
    option4: "",
    correct_answer_index: "0",
    explanation: ""
  })

  const wardAutoOpen = useRef(false)
  useEffect(() => {
    if (wardAutoOpen.current || !user || typeof window === "undefined") return
    if (new URLSearchParams(window.location.search).get("ward") === "1") { wardAutoOpen.current = true; setIsManagingCases(true); fetchAllCases() }
  }, [user])
  const profileRef = useMemo(() => (!db || !user) ? null : doc(db, 'users', user.uid), [db, user])
  const { data: profile, loading: profileLoading } = useDoc(profileRef)

  const subjectsQuery = useMemo(() => (!db) ? null : query(collection(db, 'subjects'), orderBy('name', 'asc')), [db])
  const { data: subjects, loading: subjectsLoading } = useCollection(subjectsQuery)

  const pdfTopics = useMemo(() => subjectContent.topics.filter(t => t.contentType === 'pdf'), [subjectContent.topics])
  const videoTopics = useMemo(() => subjectContent.topics.filter(t => t.contentType === 'video'), [subjectContent.topics])
  const groupedMindmaps = useMemo(() => groupByUnit(subjectContent.mindmaps), [subjectContent.mindmaps])

  const groupedQuestions = useMemo(() => {
    const groups: Record<string, Record<string, any[]>> = {}
    subjectContent.questions.forEach(q => {
      const unit = q.unit_title || "Uncategorised"
      const topic = q.topic_title || "General"
      if (!groups[unit]) groups[unit] = {}
      if (!groups[unit][topic]) groups[unit][topic] = []
      groups[unit][topic].push(q)
    })
    return Object.entries(groups).map(([unit, topics]) => ({
      unit,
      topics: Object.entries(topics).map(([topic, questions]) => ({ topic, questions }))
    }))
  }, [subjectContent.questions])

  const fetchSubjectDetails = async () => {
    if (!db || !activeSubject) return
    setLoadingContent(true)
    try {
      const subjectId = activeSubject.toLowerCase().replace(/\s+/g, '-')
      
      const topicsSnap = await getDocs(collection(db, 'subjects', subjectId, 'topics'))
      const topics = topicsSnap.docs.map(d => ({ ...d.data(), id: d.id }))
      
      const mindmapsSnap = await getDocs(collection(db, 'subjects', subjectId, 'mindmaps'))
      const mindmaps = mindmapsSnap.docs.map(d => ({ ...d.data(), id: d.id }))

      // Old questions live in Supabase, new ones go to Neon - merge both for the admin view
      let questions: any[] = []
      try {
        const res = await fetch('/api/questions?subject_id=' + subjectId)
        const json = await res.json()
        if (json.data) questions = json.data
      } catch (e: any) {
        console.warn('Combined question fetch failed, falling back to Supabase only:', e)
        const { data: sbData, error } = await supabase
          .from('questions')
          .select('*')
          .or(`subject_id.eq.${subjectId},subject_id.eq.${subjectId.toLowerCase()}`)
          .order('unit_number', { ascending: true })
          .range(0, 9999)
        if (error) throw error
        questions = sbData || []
      }

      setSubjectContent({ topics, mindmaps, questions: questions || [] })
    } catch (e: any) {
      toast({ variant: "destructive", title: "Sync Error", description: e.message })
    } finally {
      setLoadingContent(false)
    }
  }

  useEffect(() => {
    fetchSubjectDetails()
  }, [activeSubject, db])

  if (authLoading || profileLoading) return <div className="h-screen flex items-center justify-center"><Loader2 className="h-10 w-10 text-primary animate-spin" /></div>
  if (!user || (profile as any)?.role !== 'admin') return <div className="h-[80vh] flex flex-col items-center justify-center p-6 text-center"><Lock className="h-12 w-12 text-destructive mb-4" /><h1 className="text-2xl font-bold">Admin Restricted</h1><Link href="/"><Button className="mt-4">Return Home</Button></Link></div>

  async function handleDeleteSubject(s: any) {
    if (!db || !confirm(`DANGER: This will delete the entire \"${s.name}\" subject record. Contents (topics, mindmaps) must be cleared first. Proceed?`)) return
    
    const subjectRef = doc(db, 'subjects', s.id)
    try {
      await deleteDoc(subjectRef)
      toast({ title: "Subject Removed" })
      setActiveSubject(null)
    } catch (e: any) {
      toast({ variant: "destructive", title: "Delete Failed", description: e.message })
    }
  }

  async function handleDeleteMindmap(mm: any) {
    if (!db || !confirm(`Delete mindmap "${mm.title}"?`)) return

    const subjectId = mm.subjectId
    const mmRef = doc(db, 'subjects', subjectId, 'mindmaps', mm.id)

    try {
      await deleteDoc(mmRef)
      await updateDoc(doc(db, 'subjects', subjectId), { mindmapCount: increment(-1) })

      if (mm.storagePath) {
        if (mm.storageProvider === "firebase" && storage) {
          try {
            await deleteObject(storageRef(storage, mm.storagePath))
          } catch (e) { console.warn("Firebase Storage delete failed (may already be gone):", e) }
        } else {
          try {
            await supabase.storage.from('mindmaps').remove([mm.storagePath])
          } catch (e) { console.warn("Supabase Storage delete failed (may already be gone):", e) }
        }
      }

      setSubjectContent(prev => ({ ...prev, mindmaps: prev.mindmaps.filter(m => m.id !== mm.id) }))
      toast({ title: "Mindmap Removed" })
    } catch (e: any) {
      toast({ variant: "destructive", title: "Delete Failed", description: e.message })
    }
  }

  async function handleMoveMindmap(unitMindmaps: any[], index: number, direction: "up" | "down") {
    if (!db) return
    const targetIndex = direction === "up" ? index - 1 : index + 1
    if (targetIndex < 0 || targetIndex >= unitMindmaps.length) return
    const reordered = [...unitMindmaps]
    const [moved] = reordered.splice(index, 1)
    reordered.splice(targetIndex, 0, moved)
    try {
      await Promise.all(reordered.map((mm, i) =>
        updateDoc(doc(db, 'subjects', mm.subjectId, 'mindmaps', mm.id), { order: i * 10 })
      ))
      fetchSubjectDetails()
    } catch (e: any) {
      toast({ variant: "destructive", title: "Reorder Failed", description: e.message })
    }
  }

  async function handleReassignMindmapUnit(mm: any, newUnit: string) {
    if (!db || !newUnit.trim()) return
    try {
      await updateDoc(doc(db, 'subjects', mm.subjectId, 'mindmaps', mm.id), { unitName: newUnit.trim() })
      toast({ title: "Mindmap Moved", description: `Moved to ${newUnit.trim()}` })
      fetchSubjectDetails()
    } catch (e: any) {
      toast({ variant: "destructive", title: "Move Failed", description: e.message })
    }
  }

  async function handleGenerateCase() {
    if (!caseGenSpecialty.trim() || !caseGenTopic.trim()) {
      toast({ variant: "destructive", title: "Enter a specialty and topic first" })
      return
    }
    setGeneratingCase(true)
    setDraftCase(null)
    try {
      const result = await generateClinicalCase({ subject: caseGenSpecialty.trim(), topic: caseGenTopic.trim(), difficulty: caseGenDifficulty })
      if (result.error || !result.case) throw new Error(result.error || "No case returned")
      setDraftCase(result.case)
    } catch (e: any) {
      toast({ variant: "destructive", title: "Generation Failed", description: e.message })
    } finally {
      setGeneratingCase(false)
    }
  }

  async function handleGenerate100(expert: boolean = false) {
    if (!db || !user) return
    if (!confirm(expert ? "Generate the 200 EXPERT Ward Round cases? It takes about 45-75 minutes. Keep this tab open. Cases that already exist are skipped." : "Generate the 100 Ward Round cases? It takes about 10-15 minutes. Keep this tab open. Cases that already exist are skipped.")) return
    batchStopRef.current = false
    const have = new Set(allCases.map((c: any) => c.id))
    const todo = CASE_TOPICS.filter((t) => !!t.expert === expert && !have.has(t.id))
    let idx = 0, done = 0, failed = 0
    setBatchRun({ done, total: todo.length, failed, running: true })
    const worker = async () => {
      while (!batchStopRef.current) {
        const t = todo[idx++]
        if (!t) return
        try {
          const idToken = await user.getIdToken()
          const res = await fetch("/api/admin/ward-case", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ idToken, topicId: t.id }) })
          if (res.ok) done++; else failed++
        } catch { failed++ }
        setBatchRun({ done, total: todo.length, failed, running: true })
      }
    }
    await Promise.all([worker(), worker(), worker(), worker()])
    setBatchRun({ done, total: todo.length, failed, running: false })
    fetchAllCases()
  }

  async function handleSaveCase() {
    if (!db || !draftCase) return
    setSavingCase(true)
    try {
      const caseId = `case-${Date.now()}`
      await setDoc(doc(db, 'cases', caseId), {
        ...draftCase,
        id: caseId,
        specialty: caseGenSpecialty.trim(),
        tier: caseGenTier,
        order: Date.now(),
        createdAt: new Date().toISOString()
      })
      toast({ title: "Case Saved" })
      setDraftCase(null)
      setCaseGenTopic("")
      fetchAllCases()
    } catch (e: any) {
      toast({ variant: "destructive", title: "Save Failed", description: e.message })
    } finally {
      setSavingCase(false)
    }
  }

  async function handleDeleteCase(c: any) {
    if (!db || !confirm(`Delete case "${c.title}"?`)) return
    try {
      await deleteDoc(doc(db, 'cases', c.id))
      toast({ title: "Case Deleted" })
      fetchAllCases()
    } catch (e: any) {
      toast({ variant: "destructive", title: "Delete Failed", description: e.message })
    }
  }

  async function handleDeleteQuestion(qId: number) {
    if (!confirm("Delete this question?")) return
    setLoadingContent(true)
    try {
      const res = await fetch("/api/questions", {
        method: "DELETE",
        body: JSON.stringify({ question_id: qId }),
      })
      const result = await res.json()
      if (!res.ok || result.error) throw new Error(result.error || "Failed to delete question")

      setSubjectContent(prev => ({
        ...prev,
        questions: prev.questions.filter(q => q.id !== qId)
      }))
      toast({ title: "Question Deleted" })
    } catch (e: any) {
      toast({ variant: "destructive", title: "Error", description: e.message })
    } finally {
      setLoadingContent(false)
    }
  }

  async function handleDeleteTopic(topicName: string) {
    if (!confirm("Delete all questions in " + topicName + "?")) return
    setLoadingContent(true)
    try {
      const res = await fetch("/api/questions", { 
        method: "DELETE", 
        body: JSON.stringify({ subject_id: activeSubject, topic_title: topicName }) 
      })
      if (!res.ok) throw new Error("Failed to delete topic")
      
      setSubjectContent(prev => ({
        ...prev,
        topics: prev.topics.filter(t => t.name !== topicName),
        questions: prev.questions.filter(q => q.topic_title !== topicName)
      }))
      toast({ title: "Success", description: "Topic deleted" })
    } catch (e: any) {
      toast({ variant: "destructive", title: "Error", description: e.message })
    } finally {
      setLoadingContent(false)
    }
  }


  async function handleReassignTopicUnit(topicName: string, newUnit: string) {
    if (!activeSubject || !newUnit.trim()) return
    setReassigning(true)
    const subjectId = activeSubject.toLowerCase().replace(/\s+/g, '-')
    try {
      const { error } = await supabase
        .from('questions')
        .update({ unit_title: newUnit.trim() })
        .or(`subject_id.eq.${subjectId},subject_id.eq.${subjectId.toLowerCase()}`)
        .eq('topic_title', topicName)

      if (error) throw error
      toast({ title: 'Unit Updated', description: topicName + ' moved to ' + newUnit })
      setReassignTopic(null)
      setReassignUnitInput("")
      fetchSubjectDetails()
    } catch (e: any) {
      toast({ variant: 'destructive', title: 'Update Failed', description: e.message })
    } finally {
      setReassigning(false)
    }
  }

  async function handleDeleteUnit(unitName: string) {
    if (!confirm(`DANGER: Delete ALL clinical cases in unit "${unitName}"?`)) return
    setLoadingContent(true)
    try {
      const subjectId = activeSubject?.toLowerCase().replace(/\s+/g, '-')
      const res = await fetch("/api/questions", {
        method: "DELETE",
        body: JSON.stringify({ subject_id: subjectId, unit_title: unitName }),
      })
      const result = await res.json()
      if (!res.ok || result.error) throw new Error(result.error || 'Delete failed')
      toast({ title: "Unit Cleared" })
      fetchSubjectDetails()
    } catch (e: any) {
      toast({ variant: "destructive", title: "Batch Error", description: e.message })
    } finally {
      setLoadingContent(false)
    }
  }

  async function handleAddTopic() {
    if (!db || !topicForm.subjectId || !topicForm.title || !topicForm.file) {
      toast({ variant: "destructive", title: "Missing Information" })
      return
    }

    setUploading(true)
    try {
      const subjectId = topicForm.subjectId.toLowerCase().replace(/\s+/g, '-')
      const fileId = `${Date.now()}-${topicForm.file.name.replace(/\s+/g, '_')}`
      const storagePath = `${subjectId}/${fileId}`
      
      const { error: uploadError } = await supabase.storage.from('notes-pdf').upload(storagePath, topicForm.file)
      if (uploadError) throw uploadError

      const { data: { publicUrl } } = supabase.storage.from('notes-pdf').getPublicUrl(storagePath)

      const topicId = fileId.replace(/\.[^/.]+$/, "").replace(/\s+/g, '-')
      const subjectRef = doc(db, 'subjects', subjectId)
      const topicRef = doc(db, 'subjects', subjectId, 'topics', topicId)

      await setDoc(subjectRef, {
        id: subjectId,
        name: topicForm.subjectId,
        iconName: "BookOpen",
        topicCount: increment(1)
      }, { merge: true })

      await setDoc(topicRef, {
        id: topicId,
        subjectId: subjectId,
        unitName: topicForm.unitName,
        title: topicForm.title,
        contentUrl: publicUrl,
        storagePath: storagePath,
        contentType: "pdf",
        importance: topicForm.importance,
        tier: topicForm.tier,
        createdAt: new Date().toISOString()
      })

      toast({ title: "Note Published" })
      setIsAddingTopic(false)
      setActiveSubject(topicForm.subjectId)
    } catch (e: any) {
      toast({ variant: "destructive", title: "Upload Failed", description: e.message })
    } finally {
      setUploading(false)
    }
  }

  async function handleAddVideo() {
    if (!db || !videoForm.subjectId || !videoForm.title || !videoForm.url) {
      toast({ variant: "destructive", title: "Missing Information" })
      return
    }

    setUploading(true)
    try {
      const subjectId = videoForm.subjectId.toLowerCase().replace(/\s+/g, '-')
      const topicId = `vid-${Date.now()}`
      
      const subjectRef = doc(db, 'subjects', subjectId)
      const topicRef = doc(db, 'subjects', subjectId, 'topics', topicId)

      await setDoc(subjectRef, {
        id: subjectId,
        name: videoForm.subjectId,
        iconName: "Video",
        topicCount: increment(1)
      }, { merge: true })

      await setDoc(topicRef, {
        id: topicId,
        subjectId: subjectId,
        unitName: videoForm.unitName,
        title: videoForm.title,
        contentUrl: videoForm.url,
        contentType: "video",
        importance: videoForm.importance,
        tier: videoForm.tier,
        createdAt: new Date().toISOString()
      })

      toast({ title: "Video Added" })
      setIsAddingVideo(false)
      setActiveSubject(videoForm.subjectId)
    } catch (e: any) {
      toast({ variant: "destructive", title: "Error", description: e.message })
    } finally {
      setUploading(false)
    }
  }

  async function handleAddMindmap() {
    if (!db || !mindmapForm.subjectId || !mindmapForm.title || !mindmapForm.file) {
      toast({ variant: "destructive", title: "Missing Information" })
      return
    }

    setUploading(true)
    try {
      if (!storage) throw new Error("Storage not initialized")
      const subjectId = mindmapForm.subjectId.toLowerCase().replace(/\s+/g, '-')
      const fileId = `${Date.now()}-${mindmapForm.file.name.replace(/\s+/g, '_')}`
      const storagePath = `mindmaps/${subjectId}/${fileId}`

      const fileRef = storageRef(storage, storagePath)
      await uploadBytes(fileRef, mindmapForm.file)
      const { getDownloadURL } = await import("firebase/storage")
      const publicUrl = await getDownloadURL(fileRef)

      const mmId = fileId.replace(/\.[^/.]+$/, "").replace(/\s+/g, '-')
      const subjectRef = doc(db, 'subjects', subjectId)
      const mmRef = doc(db, 'subjects', subjectId, 'mindmaps', mmId)

      await setDoc(subjectRef, {
        id: subjectId,
        name: mindmapForm.subjectId,
        iconName: "Network",
        mindmapCount: increment(1)
      }, { merge: true })

      await setDoc(mmRef, {
        id: mmId,
        subjectId: subjectId,
        unitName: mindmapForm.unitName,
        order: Date.now(),
        title: mindmapForm.title,
        imageUrl: publicUrl,
        storagePath: storagePath,
        storageProvider: "firebase",
        tier: mindmapForm.tier,
        createdAt: new Date().toISOString()
      })

      toast({ title: "Mindmap Added" })
      setIsAddingMindmap(false)
      setActiveSubject(mindmapForm.subjectId)
    } catch (e: any) {
      toast({ variant: "destructive", title: "Upload Failed", description: e.message })
    } finally {
      setUploading(false)
    }
  }

  async function handleSaveQuestion() {
    if (!qbankForm.subjectId || !qbankForm.question_text || !qbankForm.option1 || !qbankForm.option2) {
      toast({ variant: "destructive", title: "Incomplete Form" })
      return
    }

    setUploading(true)
    try {
      const subjectId = qbankForm.subjectId.toLowerCase().replace(/\s+/g, '-')
      const payload = {
        subject_id: subjectId,
        unit_title: qbankForm.unit_title,
        topic_title: qbankForm.topic_title,
        question_text: qbankForm.question_text,
        option1: qbankForm.option1,
        option2: qbankForm.option2,
        option3: qbankForm.option3,
        option4: qbankForm.option4,
        correct_answer_index: parseInt(qbankForm.correct_answer_index),
        explanation: qbankForm.explanation
      }

      if (qbankForm.id) {
        const { error } = await supabase.from('questions').update(payload).eq('id', qbankForm.id)
        if (error) throw error
        toast({ title: "Question Updated" })
      } else {
        const { error } = await supabase.from('questions').insert([payload])
        if (error) throw error
        toast({ title: "Question Added" })
      }
      setIsEditingQuestion(false)
      fetchSubjectDetails()
    } catch (e: any) {
      toast({ variant: "destructive", title: "Error", description: e.message })
    } finally {
      setUploading(false)
    }
  }

  function detectRowShift(parts: any[]): boolean {
    if (!parts[6] && parts[6] !== 0) return true
    const v = parseInt(parts[6])
    return isNaN(v) || v < 0 || v > 3
  }

  function recoverCorrectIndex(opts: string[], explanation: string): number {
    if (!explanation) return 0
    const boldMatch = explanation.match(/\*\*(.+?)\*\*/)
    if (boldMatch) {
      const term = boldMatch[1].toLowerCase()
      for (let i = 0; i < opts.length; i++) {
        if (opts[i] && opts[i].toLowerCase().includes(term)) return i
      }
    }
    return 0
  }

  async function aiFixBatch(questions: any[], onProgress: (n: number, msg: string) => void): Promise<{ fixed: any[], log: any[] }> {
    const BATCH = 8
    const fixLog: any[] = []
    const allFixed: any[] = []
    for (let i = 0; i < questions.length; i += BATCH) {
      const batch = questions.slice(i, i + BATCH)
      try {
        const res = await fetch("/api/csv-fix", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ questions: batch })
        })
        if (!res.ok) throw new Error("API error: " + res.status)
        const data = await res.json()
        const fixed = data.fixed || batch
        const log = data.log || []
        log.forEach((l: any) => fixLog.push({ ...l, row: i + l.row }))
        fixed.forEach((q: any) => allFixed.push(q))
      } catch (err) {
        batch.forEach((q: any) => allFixed.push(q))
      }
      onProgress(Math.min(i + BATCH, questions.length), "")
      await new Promise(r => setTimeout(r, 200))
    }
    return { fixed: allFixed, log: fixLog }
  }
  function handleImportCSV(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file || !activeSubject) return
    Papa.parse(file, {
      header: false,
      skipEmptyLines: true,
      complete: async (results) => {
        const rows = (results.data as string[][]).slice(1)
        const allQuestions: any[] = []
        rows.forEach((parts: any[]) => {
          if (!parts || parts.length < 8) return
          const unit = parts[0]?.trim() || ""
          const topic = parts[1]?.trim() || "General"
          const question = parts[2]?.trim()
          const o1 = parts[3]?.trim()
          const o2 = parts[4]?.trim()
          const o3 = parts[5]?.trim() || ""
          const o4 = parts[6]?.trim() || ""
          const correctRaw = parseInt(parts[7])
          const correct = (!isNaN(correctRaw) && correctRaw >= 0 && correctRaw <= 3) ? correctRaw : 0
          const explanation = parts[8]?.trim() || ""
          if (!question || !o1 || !o2) return
          allQuestions.push({ unit_title: unit, topic_title: topic, question_text: question, option1: o1, option2: o2, option3: o3, option4: o4, correct_answer_index: correct, explanation })
        })
        if (allQuestions.length === 0) {
          toast({ variant: "destructive", title: "No valid rows found", description: "Check your CSV format." })
          return
        }
        let fixed = allQuestions
        let log: any[] = []
        if (useAiFixer) {
          setAiFixing(true)
          setIsUploadingQBank(false)
          setIsUploadingQBank(false)
          toast({ title: 'AI Fixing CSV...', description: 'Checking ' + allQuestions.length + ' questions for errors.' })
          setAiFixProgress({ done: 0, total: allQuestions.length, message: 'Starting...' })
          const result = await aiFixBatch(allQuestions, (done, message) => {
            setAiFixProgress({ done, total: allQuestions.length, message: message || '' })
          })
          fixed = result.fixed
          log = result.log
          setAiFixLog(log)
          setAiFixing(false)
        } else {
          setIsUploadingQBank(false)
          setAiFixLog([])
        }
        const topicMap: Record<string, { unit: string, questions: any[] }> = {}
        fixed.forEach((q: any) => {
          const t = q.topic_title || 'General'
          if (!topicMap[t]) topicMap[t] = { unit: q.unit_title || '', questions: [] }
          topicMap[t].questions.push(q)
        })
        const parsed = Object.entries(topicMap).map(([name, data], i) => ({ topicName: name, unitName: data.unit, questions: data.questions, order: i }))
        setCsvParsedTopics(parsed)
        setCsvUnitName('')
        setShowCsvOrganizer(true)
        if (!useAiFixer) {
          toast({ title: 'Imported without AI check', description: fixed.length + ' questions ready to import as-is.' })
        } else if (log.length > 0) {
          toast({ title: 'AI fixed ' + log.length + ' issues', description: 'Review the fix log in the organizer.' })
        } else {
          toast({ title: 'CSV looks clean!', description: fixed.length + ' questions ready to import.' })
        }
      },
      error: (err: any) => {
        toast({ variant: 'destructive', title: 'Parse Error', description: err.message })
        setAiFixing(false)
      }
    })
  }

  async function handleConfirmImport() {
    if (!activeSubject) return
    setUploading(true)
    const subjectId = activeSubject.toLowerCase().replace(/\s+/g, "-")
    try {
      const allQuestions = csvParsedTopics
        .sort((a, b) => a.order - b.order)
        .flatMap(t => t.questions.map((q: any) => ({ ...q, subject_id: subjectId, topic_title: t.topicName, unit_title: t.unitName || csvUnitName || null })))
      if (allQuestions.length === 0) throw new Error("No questions to import.")

      const CHUNK_SIZE = 50
      const MAX_RETRIES = 3
      let inserted = 0

      for (let i = 0; i < allQuestions.length; i += CHUNK_SIZE) {
        const chunk = allQuestions.slice(i, i + CHUNK_SIZE)
        let attempt = 0
        let lastError: any = null

        while (attempt < MAX_RETRIES) {
          try {
            const res = await fetch('/api/questions', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ questions: chunk }),
            })
            const json = await res.json()
            if (!res.ok || json.error) throw new Error(json.error || ("HTTP " + res.status))
            lastError = null
            break
          } catch (err: any) {
            lastError = err
            attempt++
            if (attempt < MAX_RETRIES) {
              toast({ title: "Retrying...", description: "Row " + (i + 1) + ": " + err.message + ", retry " + attempt + "/" + (MAX_RETRIES - 1) })
              await new Promise(r => setTimeout(r, 1000 * attempt))
              continue
            }
            break
          }
        }

        if (lastError) {
          throw new Error("Failed at row " + (i + 1) + ": " + (lastError.message || lastError))
        }

        inserted += chunk.length
        toast({ title: "Importing...", description: inserted + " of " + allQuestions.length + " questions saved." })
      }

      toast({ title: "Import Successful", description: "Added " + allQuestions.length + " questions across " + csvParsedTopics.length + " topics." })
      setShowCsvOrganizer(false)
      setCsvParsedTopics([])
      setAiFixLog([])
      fetchSubjectDetails()
    } catch (e: any) {
      toast({ variant: "destructive", title: "Import Failed", description: e.message })
    } finally {
      setUploading(false)
    }
  }


  async function handleExportCSV() {
    if (!activeSubject) return
    const subjectId = activeSubject.toLowerCase().replace(/\s+/g, "-")
    try {
      toast({ title: "Exporting...", description: "Fetching all questions for " + activeSubject })
      // Fetch from BOTH Neon and Supabase, then merge (Neon is overflow storage, Supabase holds older data)
      let neonData: any[] = []
      try {
        const neonRes = await fetch('/api/questions?subject_id=' + subjectId)
        const neonJson = await neonRes.json()
        if (neonJson.data?.length) neonData = neonJson.data
      } catch (e: any) { console.warn('Neon export fetch failed:', e) }
      let sbData: any[] = []
      try {
        const { data: sbRows, error } = await supabase
          .from("questions")
          .select("unit_title,topic_title,question_text,option1,option2,option3,option4,correct_answer_index,explanation")
          .eq("subject_id", subjectId)
          .order("unit_title", { ascending: true })
        if (!error && sbRows?.length) sbData = sbRows
      } catch (e: any) { console.warn('Supabase export fetch failed:', e) }
      const seen = new Set<string>()
      const data: any[] = []
      ;[...neonData, ...sbData].forEach((q: any) => {
        const key = (q.topic_title || '') + '|' + (q.question_text || '')
        if (!seen.has(key)) {
          seen.add(key)
          data.push(q)
        }
      })
      if (!data || data.length === 0) {
        toast({ variant: "destructive", title: "No questions found" })
        return
      }
      const headers = ["unit_title","topic_title","question_text","option1","option2","option3","option4","correct_answer_index","explanation"]
      const csvRows = [headers.join(",")]
      data.forEach((q: any) => {
        const row = headers.map(h => {
          const val = String(q[h] ?? "").replace(/"/g, "\"\"")
          return val.includes(",") || val.includes("\n") || val.includes("\"") ? `"${val}"` : val
        })
        csvRows.push(row.join(","))
      })
      const blob = new Blob([csvRows.join("\n")], { type: "text/csv" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = subjectId + "-qbank.csv"
      a.click()
      URL.revokeObjectURL(url)
      toast({ title: "Export Complete", description: data.length + " questions exported." })
    } catch (e: any) {
      toast({ variant: "destructive", title: "Export Failed", description: e.message })
    }
  }
  const SUBJECT_ALIASES: Record<string, string> = {
    "fmt": "Forensic Medicine",
    "forensic medicine": "Forensic Medicine",
    "obg": "Obstetrics & Gynaecology",
    "obs & gyn": "Obstetrics & Gynaecology",
    "obstetrics": "Obstetrics & Gynaecology",
    "obstetrics & gynaecology": "Obstetrics & Gynaecology",
    "obstetrics and gynaecology": "Obstetrics & Gynaecology",
    "ortho": "Orthopaedics",
    "orthopedics": "Orthopaedics",
    "orthopaedics": "Orthopaedics",
    "psm": "Community Medicine",
    "community medicine": "Community Medicine",
    "preventive and social medicine": "Community Medicine",
    "pediatrics": "Paediatrics",
    "paediatrics": "Paediatrics",
    "peds": "Paediatrics",
    "anaesthesia": "Anaesthesia",
    "anesthesia": "Anaesthesia",
    "ent": "ENT",
    "obgy": "Obstetrics & Gynaecology"
  }
  function normalizeSubject(raw: string | null | undefined): string | null {
    if (!raw) return null
    const trimmed = raw.trim()
    if (!trimmed) return null
    const key = trimmed.toLowerCase()
    return SUBJECT_ALIASES[key] || trimmed
  }

  async function handleImportPYQ(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    if (!pyqBulkExam || !pyqBulkYear) {
      toast({ variant: "destructive", title: "Set Exam Type and Year first" })
      e.target.value = ""
      return
    }
    setUploading(true)

    Papa.parse(file, {
      header: false,
      skipEmptyLines: true,
      complete: async (results) => {
        try {
          const allRows = results.data as string[][]
          const headerRow = (allRows[0] || []).map(h => (h || '').trim().toLowerCase())
          const isOldFormat = headerRow.includes('exam_type') && headerRow.includes('year')
          const rows = allRows.slice(1)

          const questions = rows.map(parts => {
            if (isOldFormat) {
              if (!parts || parts.length < 9 || !parts[3]) return null
              return {
                exam_type: parts[0]?.trim(),
                year: parseInt(parts[1]),
                subject: normalizeSubject(parts[2]),
                question_text: parts[3]?.trim(),
                option1: parts[4]?.trim(),
                option2: parts[5]?.trim(),
                option3: parts[6]?.trim() || null,
                option4: parts[7]?.trim() || null,
                correct_answer_index: parseInt(parts[8]) || 0,
                explanation: parts[9]?.trim() || null
              }
            }
            if (!parts || parts.length < 6 || !parts[1]) return null
            return {
              exam_type: pyqBulkExam,
              year: parseInt(pyqBulkYear),
              subject: normalizeSubject(parts[0]),
              question_text: parts[1]?.trim(),
              option1: parts[2]?.trim(),
              option2: parts[3]?.trim(),
              option3: parts[4]?.trim() || null,
              option4: parts[5]?.trim() || null,
              correct_answer_index: parseInt(parts[6]) || 0,
              explanation: parts[7]?.trim() || null
            }
          }).filter((q): q is NonNullable<typeof q> => q !== null)

          if (questions.length === 0) throw new Error("No valid question rows found in file.")

          if (pyqAiSubjectFix) {
            try {
              const subjectList = questions.map(q => q.subject).filter(Boolean)
              if (subjectList.length > 0) {
                const fixRes = await fetch('/api/pyq-subject-fix', { method: 'POST', body: JSON.stringify({ subjects: subjectList }) })
                const fixJson = await fixRes.json()
                if (fixJson.mapping) {
                  questions.forEach(q => {
                    if (q.subject && fixJson.mapping[q.subject]) q.subject = fixJson.mapping[q.subject]
                  })
                }
              }
            } catch (e) { console.warn("AI subject-fix failed, continuing with original subjects", e) }
          }

          const res = await fetch('/api/pyq', { method: 'POST', body: JSON.stringify({ questions }) })
          const json = await res.json()
          if (json.error) throw new Error(json.error)

          toast({ title: "PYQ Imported", description: `${questions.length} questions added.` })
          setIsUploadingPYQ(false)
        } catch (e: any) {
          toast({ variant: "destructive", title: "Import Failed", description: e.message })
        } finally {
          setUploading(false)
        }
      },
      error: (err) => {
        toast({ variant: "destructive", title: "Parse Error", description: err.message })
        setUploading(false)
      }
    })
  }


  async function fetchPYQQuestions() {
    setLoadingPYQ(true)
    try {
      const res = await fetch('/api/pyq')
      const json = await res.json()
      if (json.error) throw new Error(json.error)
      setPyqQuestions(json.data || [])
    } catch (e: any) {
      toast({ variant: "destructive", title: "Fetch Failed", description: e.message })
    } finally {
      setLoadingPYQ(false)
    }
  }

  async function handleSavePYQ() {
    if (!pyqForm.question_text || !pyqForm.option1 || !pyqForm.option2) {
      toast({ variant: "destructive", title: "Incomplete Form" })
      return
    }
    setUploading(true)
    try {
      const payload = {
        exam_type: pyqForm.exam_type,
        year: parseInt(pyqForm.year),
        subject: normalizeSubject(pyqForm.subject),
        question_text: pyqForm.question_text,
        option1: pyqForm.option1,
        option2: pyqForm.option2,
        option3: pyqForm.option3 || null,
        option4: pyqForm.option4 || null,
        correct_answer_index: parseInt(pyqForm.correct_answer_index),
        explanation: pyqForm.explanation || null
      }
      if (editingPYQId) {
        const res = await fetch('/api/pyq', { method: 'PUT', body: JSON.stringify({ id: editingPYQId, ...payload }) })
        const json = await res.json()
        if (json.error) throw new Error(json.error)
        toast({ title: "PYQ Updated" })
      } else {
        const res = await fetch('/api/pyq', { method: 'POST', body: JSON.stringify({ questions: [payload] }) })
        const json = await res.json()
        if (json.error) throw new Error(json.error)
        toast({ title: "PYQ Added" })
      }
      setEditingPYQId(null)
      setPyqForm({
        exam_type: "NEET PG",
        year: new Date().getFullYear().toString(),
        subject: "",
        question_text: "",
        option1: "",
        option2: "",
        option3: "",
        option4: "",
        correct_answer_index: "0",
        explanation: ""
      })
      fetchPYQQuestions()
    } catch (e: any) {
      toast({ variant: "destructive", title: "Save Failed", description: e.message })
    } finally {
      setUploading(false)
    }
  }

  async function handleDeletePYQ(id: string) {
    if (!confirm("Delete this PYQ question?")) return
    const original = [...pyqQuestions]
    setPyqQuestions(prev => prev.filter(q => q.id !== id))
    try {
      const res = await fetch('/api/pyq', { method: 'DELETE', body: JSON.stringify({ id }) })
      const json = await res.json()
      if (json.error) {
        setPyqQuestions(original)
        throw new Error(json.error)
      }
      toast({ title: "PYQ Deleted" })
    } catch (e: any) {
      toast({ variant: "destructive", title: "Delete Failed", description: e.message })
    }
  }

  function startEditPYQ(q: any) {
    setEditingPYQId(q.id)
    setPyqForm({
      exam_type: q.exam_type,
      year: q.year.toString(),
      subject: q.subject || "",
      question_text: q.question_text || q.question || q.Question || q.question,
      option1: q.option1,
      option2: q.option2,
      option3: q.option3 || "",
      option4: q.option4 || "",
      correct_answer_index: q.correct_answer_index.toString(),
      explanation: q.explanation || ""
    })
  }

  const filteredPYQ = pyqQuestions.filter(q => {
    const matchesSearch = pyqSearch === "" || q.question_text.toLowerCase().includes(pyqSearch.toLowerCase())
    const matchesExam = pyqExamFilter === "All" || q.exam_type === pyqExamFilter
    const matchesYear = pyqYearFilter === "All" || q.year.toString() === pyqYearFilter
    return matchesSearch && matchesExam && matchesYear
  })
  async function handleAddProduct() {
    if (!productForm.title || !productForm.price || !productForm.buy_link) {
      toast({ variant: "destructive", title: "Missing fields" }); return
    }
    setUploading(true)
    try {
      const { error } = await supabase.from('products').insert([{
        title: productForm.title,
        description: productForm.description,
        price: parseFloat(productForm.price),
        category: productForm.category,
        buy_link: productForm.buy_link,
        image_url: productForm.image_url || null,
        is_active: true
      }])
      if (error) throw error
      toast({ title: "Product Added" })
      setIsAddingProduct(false)
      setProductForm({ title: "", description: "", price: "", category: "Notes Pack", buy_link: "", image_url: "" })
    } catch (e: any) {
      toast({ variant: "destructive", title: "Error", description: e.message })
    } finally { setUploading(false) }
  }

  return (
    <div className="max-w-7xl mx-auto p-4 md:p-12 space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <ShieldAlert className="h-8 w-8 text-primary" /> Command Center
          </h1>
          <p className="text-muted-foreground">Manage subjects, curriculum videos, and high-yield notes.</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button onClick={() => setIsAddingTopic(true)} className="rounded-xl gap-2"><Plus className="h-4 w-4" /> New Note</Button>
          <Button onClick={() => setIsAddingVideo(true)} variant="secondary" className="rounded-xl gap-2"><Video className="h-4 w-4" /> Add Video</Button>
          <Button onClick={() => setIsAddingMindmap(true)} variant="outline" className="rounded-xl gap-2 glass"><Network className="h-4 w-4" /> New Mindmap</Button>
          <Button onClick={() => setIsUploadingPYQ(true)} variant="outline" className="rounded-xl gap-2 glass">
            <Trophy className="h-4 w-4" /> Upload PYQ
          </Button>
          <Button onClick={() => { setIsManagingCases(true); fetchAllCases(); }} className="rounded-xl gap-2 bg-gradient-to-r from-rose-600 to-orange-500 text-white">
            <HelpCircle className="h-4 w-4" /> Ward Round Cases (generate 100 / 200 expert)
          </Button>
          <Button onClick={() => { setIsManagingProfPyq(true); fetchAllProfPyq(); }} variant="outline" className="rounded-xl gap-2 glass">
            <BookOpen className="h-4 w-4" /> Manage Prof PYQ
          </Button>
          <Button onClick={() => { setIsManagingNotePacks(true); fetchAllNotePacks(); }} variant="outline" className="rounded-xl gap-2 glass">
            <FileDown className="h-4 w-4" /> Manage Notes Packs
          </Button>
          <Button onClick={() => { setIsManagingBanner(true); fetchBanners(); }} variant="outline" className="rounded-xl gap-2 glass">
            <Sparkles className="h-4 w-4" /> Manage Dashboard Ads
          </Button>
          <Button onClick={() => setIsAddingProduct(true)} variant="outline" className="rounded-xl gap-2 glass">
            <ShoppingBag className="h-4 w-4" /> Add Product
          </Button>
          <Link href="/admin/master-knowledge-extraction">
            <Button variant="outline" className="rounded-xl gap-2 glass border-purple-500/30 text-purple-400 hover:bg-purple-500/10">
              <Sparkles className="h-4 w-4" /> Master Knowledge Extraction
            </Button>
          </Link>
          <Link href="/admin/ai-textbook-ingest">
            <Button variant="outline" className="rounded-xl gap-2 glass border-purple-500/30 text-purple-400 hover:bg-purple-500/10">
              <Sparkles className="h-4 w-4" /> AI Textbook Ingestion
            </Button>
          </Link>
          <Link href="/admin/notes-bulk-generator">
            <Button variant="outline" className="rounded-xl gap-2 glass border-purple-500/30 text-purple-400 hover:bg-purple-500/10">
              <Sparkles className="h-4 w-4" /> Notes Bulk Generator
            </Button>
          </Link>
          <Link href="/admin/ai-notes-generator">
            <Button variant="outline" className="rounded-xl gap-2 glass border-purple-500/30 text-purple-400 hover:bg-purple-500/10">
              <Sparkles className="h-4 w-4" /> AI Notes Generator
            </Button>
          </Link>
          <Link href="/admin/notes-manager">
            <Button variant="outline" className="rounded-xl gap-2 glass border-red-500/30 text-red-400 hover:bg-red-500/10">
              <Trash2 className="h-4 w-4" /> Manage Notes
            </Button>
          </Link>
          <Link href="/admin/mindmaps-from-notes">
            <Button variant="outline" className="rounded-xl gap-2 glass border-teal-500/30 text-teal-400 hover:bg-teal-500/10">
              <Network className="h-4 w-4" /> Mindmaps from Notes
            </Button>
          </Link>
          <Link href="/admin/flashcards-from-notes">
            <Button variant="outline" className="rounded-xl gap-2 glass border-indigo-500/30 text-indigo-400 hover:bg-indigo-500/10">
              <Layers className="h-4 w-4" /> Flashcards from Notes
            </Button>
          </Link>
          <Link href="/admin/qbank-from-notes">
            <Button variant="outline" className="rounded-xl gap-2 glass border-orange-500/30 text-orange-400 hover:bg-orange-500/10">
              <HelpCircle className="h-4 w-4" /> QBank from Notes
            </Button>
          </Link>
          <Link href="/admin/notes-repair">
            <Button variant="outline" className="rounded-xl gap-2 glass border-rose-500/30 text-rose-400 hover:bg-rose-500/10">
              <AlertTriangle className="h-4 w-4" /> Fix Truncated Notes
            </Button>
          </Link>
          <Link href="/admin/affiliates">
            <Button variant="outline" className="rounded-xl gap-2 glass border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/10">
              <Gift className="h-4 w-4" /> Manage Affiliates
            </Button>
          </Link>
          <Link href="/admin/grand-test-import">
            <Button variant="outline" className="rounded-xl gap-2 glass border-indigo-500/30 text-indigo-300 hover:bg-indigo-500/10">
              <Gift className="h-4 w-4" /> Grand Test Papers
            </Button>
          </Link>
          <Link href="/admin/free-access">
            <Button variant="outline" className="rounded-xl gap-2 glass border-pink-500/30 text-pink-400 hover:bg-pink-500/10">
              <Gift className="h-4 w-4" /> Free Access (Influencers)
            </Button>
          </Link>
          <Link href="/admin/long-answers">
            <Button variant="outline" className="rounded-xl gap-2 glass border-violet-500/30 text-violet-400 hover:bg-violet-500/10">
              <FileText className="h-4 w-4" /> Long Answers
            </Button>
          </Link>
          <Link href="/admin/users">
            <Button variant="outline" className="rounded-xl gap-2 glass border-sky-500/30 text-sky-400 hover:bg-sky-500/10">
              <Users className="h-4 w-4" /> Users
            </Button>
          </Link>
          <Link href="/admin/textbook-generator">
            <Button variant="outline" className="rounded-xl gap-2 glass border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10">
              <BookMarked className="h-4 w-4" /> Generate from Textbook
            </Button>
          </Link>
          <Link href="/admin/flashcard-generator">
            <Button variant="outline" className="rounded-xl gap-2 glass border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10">
              <Layers className="h-4 w-4" /> Flashcards
            </Button>
          </Link>
          <Link href="/admin/flashcard-bulk-generator">
            <Button variant="outline" className="rounded-xl gap-2 glass border-amber-500/30 text-amber-400 hover:bg-amber-500/10">
              <Zap className="h-4 w-4" /> Flashcard Bulk Generator
            </Button>
          </Link>
          <Link href="/admin/mindmap-prompt-generator">
            <Button variant="outline" className="rounded-xl gap-2 glass border-fuchsia-500/30 text-fuchsia-400 hover:bg-fuchsia-500/10">
              <Network className="h-4 w-4" /> Mind Map Prompts
            </Button>
          </Link>
          <Link href="/admin/long-answers-bulk-generator">
            <Button variant="outline" className="rounded-xl gap-2 glass border-amber-500/30 text-amber-400 hover:bg-amber-500/10">
              <FileText className="h-4 w-4" /> Long Answers Bulk
            </Button>
          </Link>
          <Link href="/admin/mindmap-generator">
            <Button variant="outline" className="rounded-xl gap-2 glass border-violet-500/30 text-violet-400 hover:bg-violet-500/10">
              <Network className="h-4 w-4" /> Mind Map Generator
            </Button>
          </Link>
          <Link href="/admin/mindmap-bulk-generator">
            <Button variant="outline" className="rounded-xl gap-2 glass border-indigo-500/30 text-indigo-400 hover:bg-indigo-500/10">
              <Network className="h-4 w-4" /> Mind Map Bulk
            </Button>
          </Link>
          <Link href="/admin/notes-image-generator">
            <Button variant="outline" className="rounded-xl gap-2 glass border-sky-500/30 text-sky-400 hover:bg-sky-500/10">
              <BookOpenText className="h-4 w-4" /> Notes Image Generator
            </Button>
          </Link>
          <Link href="/admin/quickcards">
            <Button variant="outline" className="rounded-xl gap-2 glass border-violet-500/30 text-violet-400 hover:bg-violet-500/10">
              <BookOpenText className="h-4 w-4" /> QuickCards
            </Button>
          </Link>
          <Link href="/admin/inbox">
            <Button variant="outline" className="rounded-xl gap-2 glass border-teal-500/30 text-teal-400 hover:bg-teal-500/10">
              <BookOpenText className="h-4 w-4" /> Support Inbox
            </Button>
          </Link>
          <Link href="/admin/usage">
            <Button variant="outline" className="rounded-xl gap-2 glass border-violet-500/30 text-violet-400 hover:bg-violet-500/10">
              <BarChart3 className="h-4 w-4" /> Usage &amp; Growth
            </Button>
          </Link>
          <Link href="/admin/spotters">
            <Button variant="outline" className="rounded-xl gap-2 glass border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10">
              <BarChart3 className="h-4 w-4" /> Spotters upload
            </Button>
          </Link>
          <Link href="/admin/pyq-import">
            <Button variant="outline" className="rounded-xl gap-2 glass border-sky-500/30 text-sky-400 hover:bg-sky-500/10">
              <BarChart3 className="h-4 w-4" /> PYQ Import
            </Button>
          </Link>
          <Link href="/admin/analytics">
            <Button variant="outline" className="rounded-xl gap-2 glass border-rose-500/30 text-rose-400 hover:bg-rose-500/10">
              <BarChart3 className="h-4 w-4" /> Analytics
            </Button>
          </Link>
          <Link href="/virtual-patient">
            <Button variant="outline" className="rounded-xl gap-2 glass border-teal-500/30 text-teal-400 hover:bg-teal-500/10">
              <Stethoscope className="h-4 w-4" /> OSCE Stations (Live)
            </Button>
          </Link>
          <Button 
            onClick={() => {
              setQbankForm({
                id: null,
                subjectId: activeSubject || "",
                unit_title: "",
                topic_title: "",
                question_text: "",
                option1: "",
                option2: "",
                option3: "",
                option4: "",
                correct_answer_index: "0",
                explanation: ""
              })
              setIsEditingQuestion(true)
            }} 
            variant="outline" 
            className="rounded-xl gap-2 glass"
          >
            <Database className="h-4 w-4" /> Add Case
          </Button>
        </div>
      </div>

      <div className="grid lg:grid-cols-4 gap-8">
        <Card className="lg:col-span-1 glass border-none h-fit overflow-hidden">
          <div className="p-4 border-b border-white/5 bg-white/5">
            <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
              <Layout className="h-3 w-3" /> Library Index
            </p>
          </div>
          <div className="max-h-[600px] overflow-y-auto scrollbar-hide">
            {subjectsLoading ? (
              <div className="p-12 flex justify-center"><Loader2 className="h-6 w-6 animate-spin opacity-20" /></div>
            ) : subjects?.map((s: any) => (
              <div key={s.id} className={`group relative ${activeSubject === s.name ? 'bg-primary/10' : ''}`}>
                <button 
                  onClick={() => setActiveSubject(s.name)}
                  className={`w-full p-4 flex items-center justify-between text-left hover:bg-white/5 transition-colors ${activeSubject === s.name ? 'border-r-2 border-primary' : ''}`}>
                  <div className="flex-1 min-w-0 pr-8">
                    <p className="font-bold text-sm group-hover:text-primary transition-colors truncate">{s.name}</p>
                    <div className="flex gap-2 mt-1">
                      <span className="text-[9px] text-muted-foreground uppercase">{s.topicCount || 0} Content</span>
                    </div>
                  </div>
                  <ChevronRight className={`h-4 w-4 transition-transform ${activeSubject === s.name ? 'rotate-90 text-primary' : 'opacity-10 group-hover:opacity-100'}`} />
                </button>
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDeleteSubject(s);
                  }}
                  className="absolute right-12 top-1/2 -translate-y-1/2 h-8 w-8 rounded-lg flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-destructive/10 opacity-0 group-hover:opacity-100 transition-all">
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        </Card>

        <div className="lg:col-span-3 space-y-6">
          {activeSubject ? (
            <div className="space-y-6 animate-in slide-in-from-right-4 duration-500">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <h2 className="text-2xl font-bold flex items-center gap-3">
                    <BookOpen className="h-6 w-6 text-primary" /> {activeSubject}
                  </h2>
                </div>
              </div>

              <Tabs defaultValue="notes" className="w-full">
                <TabsList className="glass border-none h-12 p-1 rounded-xl mb-6 flex-wrap">
                  <TabsTrigger value="notes" className="rounded-lg gap-2 data-[state=active]:bg-primary"><FileText className="h-4 w-4" /> PDF Notes</TabsTrigger>
                  <TabsTrigger value="videos" className="rounded-lg gap-2 data-[state=active]:bg-primary"><Video className="h-4 w-4" /> Video Curriculum</TabsTrigger>
                  <TabsTrigger value="mindmaps" className="rounded-lg gap-2 data-[state=active]:bg-primary"><Network className="h-4 w-4" /> Mindmaps</TabsTrigger>
                  <TabsTrigger value="qbank" className="rounded-lg gap-2 data-[state=active]:bg-primary"><Database className="h-4 w-4" /> QBank</TabsTrigger>
                </TabsList>

                {loadingContent ? (
                  <div className="h-64 flex items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
                ) : (
                  <>
                    <TabsContent value="notes" className="space-y-3">
                      {pdfTopics.map((t) => (
                        <Card key={t.id} className="glass border-none hover:bg-white/5 transition-colors">
                          <CardContent className="p-4 flex items-center justify-between">
                            <div className="flex items-center gap-4">
                              <div className="p-2.5 rounded-xl bg-primary/10 text-primary">
                                <FileText className="h-5 w-5" />
                              </div>
                              <div>
                                <p className="font-bold text-sm">{t.title}</p>
                                <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">{t.unitName || 'General'}</p>
                                <span className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded ${t.tier === 'paid' ? 'bg-primary/10 text-primary' : 'bg-green-500/10 text-green-400'}`}>
                                  {t.tier === 'paid' ? '👑 Paid' : '🆓 Free'}
                                </span>
                              </div>
                            </div>
                            <Button variant="ghost" size="icon" onClick={() => handleDeleteTopic(t)} className="h-9 w-9 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-xl transition-all">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </CardContent>
                        </Card>
                      ))}
                      {pdfTopics.length === 0 && <div className="text-center py-24 glass rounded-3xl text-muted-foreground">No PDF notes found for this subject.</div>}
                    </TabsContent>

                    <TabsContent value="videos" className="space-y-3">
                      {videoTopics.map((t) => (
                        <Card key={t.id} className="glass border-none hover:bg-white/5 transition-colors">
                          <CardContent className="p-4 flex items-center justify-between">
                            <div className="flex items-center gap-4">
                              <div className="p-2.5 rounded-xl bg-secondary/10 text-secondary">
                                <Video className="h-5 w-5" />
                              </div>
                              <div>
                                <p className="font-bold text-sm">{t.title}</p>
                                <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">{t.unitName || 'General'}</p>
                                <span className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded ${t.tier === 'paid' ? 'bg-primary/10 text-primary' : 'bg-green-500/10 text-green-400'}`}>
                                  {t.tier === 'paid' ? '👑 Paid' : '🆓 Free'}
                                </span>
                              </div>
                            </div>
                            <Button variant="ghost" size="icon" onClick={() => handleDeleteTopic(t)} className="h-9 w-9 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-xl transition-all">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </CardContent>
                        </Card>
                      ))}
                      {videoTopics.length === 0 && <div className="text-center py-24 glass rounded-3xl text-muted-foreground">No video lectures found for this subject.</div>}
                    </TabsContent>

                    <TabsContent value="mindmaps" className="space-y-6">
                      {groupedMindmaps.map((group: any) => (
                        <div key={group.unitName} className="space-y-3">
                          <h3 className="text-sm font-bold uppercase tracking-widest text-muted-foreground">{group.unitName}</h3>
                          <div className="grid md:grid-cols-2 gap-4">
                            {group.items.map((mm: any, index: number) => (
                              <Card key={mm.id} className="glass border-none overflow-hidden group">
                                <div className="aspect-video relative">
                                  <img src={mm.imageUrl} alt={mm.title} className="w-full h-full object-cover opacity-50 group-hover:opacity-80 transition-opacity" />
                                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                                    <Button variant="secondary" size="icon" className="h-8 w-8 rounded-xl" disabled={index === 0} onClick={() => handleMoveMindmap(group.items, index, "up")}><ChevronUp className="h-4 w-4" /></Button>
                                    <Button variant="secondary" size="icon" className="h-8 w-8 rounded-xl" disabled={index === group.items.length - 1} onClick={() => handleMoveMindmap(group.items, index, "down")}><ChevronDown className="h-4 w-4" /></Button>
                                    <Button variant="secondary" size="icon" className="h-8 w-8 rounded-xl" onClick={() => { const nu = window.prompt("Move to unit:", mm.unitName || ""); if (nu !== null) handleReassignMindmapUnit(mm, nu) }}><Layers className="h-4 w-4" /></Button>
                                    <Button variant="destructive" size="sm" onClick={() => handleDeleteMindmap(mm)} className="rounded-xl"><Trash2 className="h-4 w-4 mr-2" /> Delete</Button>
                                  </div>
                                </div>
                                <div className="p-3 bg-card"><p className="text-sm font-bold truncate">{mm.title}</p></div>
                              </Card>
                            ))}
                          </div>
                        </div>
                      ))}
                      {subjectContent.mindmaps.length === 0 && <div className="text-center py-24 glass rounded-3xl text-muted-foreground">No mindmaps found.</div>}
                    </TabsContent>

                    <TabsContent value="qbank" className="space-y-4">
                      <div className="flex items-center justify-between px-2">
                        <h4 className="font-bold flex items-center gap-2 text-primary">
                          <Database className="h-4 w-4" /> Curriculum-Based QBank
                        </h4>
                        <div className="flex gap-2">
                          <Button 
                            variant="outline" 
                            size="sm" 
                            className="rounded-lg gap-2 text-[10px] font-bold uppercase tracking-widest glass"
                            onClick={() => {
                              setQbankForm({
                                id: null,
                                subjectId: activeSubject || "",
                                unit_title: "",
                                topic_title: "",
                                question_text: "",
                                option1: "",
                                option2: "",
                                option3: "",
                                option4: "",
                                correct_answer_index: "0",
                                explanation: ""
                              })
                              setIsEditingQuestion(true)
                            }}>
                            <Plus className="h-3 w-3" /> Add Case
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="rounded-lg gap-2 text-[10px] font-bold uppercase tracking-widest glass"
                            onClick={() => setIsUploadingQBank(true)}>
                            <Upload className="h-3 w-3" /> Bulk Import
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="rounded-lg gap-2 text-[10px] font-bold uppercase tracking-widest glass border-green-500/30 text-green-400 hover:bg-green-500/10"
                            onClick={handleExportCSV}>
                            <FileDown className="h-3 w-3" /> Export CSV
                          </Button>
                          <Link href="/admin/qbank-generator">
                            <Button
                              variant="outline"
                              size="sm"
                              className="rounded-lg gap-2 text-[10px] font-bold uppercase tracking-widest glass border-accent/30 text-accent hover:bg-accent/10">
                              <Wand2 className="h-3 w-3" /> AI Generate
                            </Button>
                          </Link>
                        </div>
                      </div>

                      <div className="p-6 glass rounded-2xl">
                         {groupedQuestions.length > 0 ? (
                            <Accordion type="multiple" className="space-y-3">
                               {groupedQuestions.map((group, gIdx) => (
                                 <AccordionItem key={gIdx} value={`unit-${gIdx}`} className="border-none bg-white/5 rounded-xl overflow-hidden">
                                    <div className="flex items-center justify-between px-4">
                                        <AccordionTrigger className="flex-1 hover:no-underline py-4">
                                            <div className="flex items-center gap-3">
                                                <Layers className="h-4 w-4 text-accent" />
                                                <div className="flex flex-col items-start">
                                                    <span className="font-bold text-sm tracking-tight">{group.unit}</span>
                                                    <span className="text-[10px] text-muted-foreground uppercase">{group.topics.reduce((acc, t) => acc + t.questions.length, 0)} Cases in {group.topics.length} Topics</span>
                                                </div>
                                            </div>
                                        </AccordionTrigger>
                                        <div className="flex gap-1 shrink-0">
                                            <Button
                                                variant="ghost"
                                                size="sm"
                                                className="h-6 px-2 rounded-lg text-[9px] font-bold uppercase hover:bg-primary/10 hover:text-primary gap-1"
                                                onClick={() => {
                                                    setQbankForm({
                                                        id: null,
                                                        subjectId: activeSubject || "",
                                                        unit_title: group.unit,
                                                        topic_title: "",
                                                        question_text: "",
                                                        option1: "",
                                                        option2: "",
                                                        option3: "",
                                                        option4: "",
                                                        correct_answer_index: "0",
                                                        explanation: ""
                                                    });
                                                    setIsEditingQuestion(true);
                                                }}>
                                                <Plus className="h-2.5 w-2.5" /> Add Case
                                            </Button>
                                            <Button
                                                variant="ghost"
                                                size="sm"
                                                className="h-6 px-2 rounded-lg text-[9px] font-bold uppercase hover:bg-destructive/10 hover:text-destructive gap-1"
                                                onClick={() => handleDeleteUnit(group.unit)}>
                                                <Trash2 className="h-2.5 w-2.5" /> Clear Unit
                                            </Button>
                                        </div>
                                    </div>
                                   <AccordionContent className="pb-4 px-4 space-y-6">
                                      {group.topics.map((topicGroup, tIdx) => (
                                        <div key={tIdx} className="space-y-3 pl-4 border-l border-white/10">
                                          <div className="flex items-center justify-between mb-2 bg-black/20 p-2 rounded-lg">
                                            <p className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                                              <ChevronRight className="h-3 w-3 text-accent" /> {topicGroup.topic} ({topicGroup.questions.length} cases)
                                            </p>
                                            <div className="flex gap-1">
                                              <Button 
                                                variant="ghost" 
                                                size="sm" 
                                                className="h-6 px-2 rounded-lg text-[9px] font-bold uppercase hover:bg-primary/10 hover:text-primary gap-1"
                                                onClick={() => {
                                                  setQbankForm({
                                                    id: null,
                                                    subjectId: activeSubject || "",
                                                    unit_title: group.unit,
                                                    topic_title: topicGroup.topic,
                                                    question_text: "",
                                                    option1: "",
                                                    option2: "",
                                                    option3: "",
                                                    option4: "",
                                                    correct_answer_index: "0",
                                                    explanation: ""
                                                  })
                                                  setIsEditingQuestion(true)
                                                }}>
                                                <Plus className="h-2.5 w-2.5" /> Add
                                              </Button>
                                              <Button
                                                variant="ghost"
                                                size="sm"
                                                className="h-6 px-2 rounded-lg text-[9px] font-bold uppercase hover:bg-accent/10 hover:text-accent gap-1"
                                                onClick={() => { setReassignTopic({ topic: topicGroup.topic, currentUnit: group.unit }); setReassignUnitInput(group.unit) }}>
                                                <Edit2 className="h-2.5 w-2.5" /> Move
                                              </Button>
                                              <Button 
                                                variant="ghost" 
                                                size="sm" 
                                                className="h-6 px-2 rounded-lg text-[9px] font-bold uppercase hover:bg-destructive/10 hover:text-destructive gap-1"
                                                onClick={() => handleDeleteTopic(topicGroup.topic)}>
                                                <Trash2 className="h-2.5 w-2.5" /> Clear Topic
                                              </Button>
                                            </div>
                                          </div>
                                          <div className="grid gap-2">
                                            {topicGroup.questions.map((q: any, qIdx: number) => (
                                              <div key={qIdx} className="p-3 rounded-xl bg-black/40 border border-white/5 flex items-center justify-between group/item hover:bg-white/5 transition-colors">
                                                 <div className="flex items-start gap-3 flex-1 min-w-0">
                                                   <div className="w-5 h-5 rounded-lg bg-white/5 flex items-center justify-center shrink-0 mt-0.5">
                                                     <span className="text-[9px] font-bold text-muted-foreground">{qIdx + 1}</span>
                                                   </div>
                                                   <span className="text-[11px] text-muted-foreground group-hover/item:text-white transition-colors line-clamp-2">
                                                     {q.question_text}
                                                   </span>
                                                 </div>
                                                 <div className="flex items-center gap-1">
                                                   <Button 
                                                    variant="ghost" 
                                                    size="icon" 
                                                    className="h-7 w-7 rounded-lg text-muted-foreground hover:text-accent transition-all"
                                                    onClick={() => {
                                                      setQbankForm({
                                                        id: q.id,
                                                        subjectId: q.subject_id,
                                                        unit_title: q.unit_title || q["unit_title"] || q["Unit Name"] || q["unit_title"] || q["Unit Name"] || q["Unit Name"] || q["unit_name"] || q["Unit"] || "",
                                                        topic_title: q.topic_title || "",
                                                        question_text: q.question_text || q.question || q.Question || q.question,
                                                        option1: q.option1,
                                                        option2: q.option2,
                                                        option3: q.option3,
                                                        option4: q.option4,
                                                        correct_answer_index: q.correct_answer_index.toString(),
                                                        explanation: q.explanation || ""
                                                      })
                                                      setIsEditingQuestion(true)
                                                    }}>
                                                     <Edit2 className="h-3 w-3" />
                                                   </Button>
                                                   <Button 
                                                    variant="ghost" 
                                                    size="icon" 
                                                    className="h-7 w-7 rounded-lg text-muted-foreground hover:text-destructive transition-all"
                                                    onClick={() => handleDeleteQuestion(q.id)}>
                                                     <Trash2 className="h-3 w-3" />
                                                   </Button>
                                                 </div>
                                              </div>
                                            ))}
                                          </div>
                                        </div>
                                      ))}
                                   </AccordionContent>
                                 </AccordionItem>
                               ))}
                            </Accordion>
                         ) : (
                           <div className="text-center py-24 glass rounded-3xl text-muted-foreground border-2 border-dashed border-white/5">
                             <Database className="h-12 w-12 mx-auto mb-4 opacity-10" />
                             <p className="text-sm">No curriculum-based QBank data found.</p>
                             <p className="text-[10px] mt-1">Use the buttons above to upload clinical cases.</p>
                           </div>
                         )}
                      </div>
                    </TabsContent>

                  </>
                )}
              </Tabs>
            </div>
          ) : (
            <div className="h-[500px] flex flex-col items-center justify-center glass rounded-3xl text-center space-y-4">
              <Layout className="h-16 w-16 text-muted-foreground opacity-10" />
              <p className="font-bold text-xl">Select a Subject to Manage Content</p>
            </div>
          )}
        </div>
      </div>

      <Dialog open={isUploadingPYQ} onOpenChange={(open) => { setIsUploadingPYQ(open); if (open) fetchPYQQuestions() }}>
        <DialogContent aria-describedby={undefined} className="glass border-white/10 max-w-3xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>PYQ Question Bank</DialogTitle>
          </DialogHeader>
          <Tabs defaultValue="manage" className="w-full">
            <TabsList className="glass border-none h-11 p-1 rounded-xl mb-4">
              <TabsTrigger value="manage" className="rounded-lg data-[state=active]:bg-primary">Manage</TabsTrigger>
              <TabsTrigger value="add" className="rounded-lg data-[state=active]:bg-primary">{editingPYQId ? "Edit Question" : "Add Question"}</TabsTrigger>
              <TabsTrigger value="bulk" className="rounded-lg data-[state=active]:bg-primary">Bulk Import</TabsTrigger>
            </TabsList>

            <TabsContent value="manage" className="space-y-4">
              <div className="grid grid-cols-3 gap-3">
                <Input placeholder="Search question text..." value={pyqSearch} onChange={(e) => setPyqSearch(e.target.value)} className="glass border-white/10 col-span-1" />
                <Select value={pyqExamFilter} onValueChange={setPyqExamFilter}>
                  <SelectTrigger className="glass border-white/10"><SelectValue /></SelectTrigger>
                  <SelectContent className="glass border-white/10">
                    <SelectItem value="All">All Exams</SelectItem>
                    {["NEET PG", "INICET", "USMLE Step 1", "USMLE Step 2", "FMGE"].map(e => <SelectItem key={e} value={e}>{e}</SelectItem>)}
                  </SelectContent>
                </Select>
                <Select value={pyqYearFilter} onValueChange={setPyqYearFilter}>
                  <SelectTrigger className="glass border-white/10"><SelectValue /></SelectTrigger>
                  <SelectContent className="glass border-white/10">
                    <SelectItem value="All">All Years</SelectItem>
                    {Array.from(new Set(pyqQuestions.map(q => q.year))).sort((a,b) => b-a).map(y => <SelectItem key={y} value={y.toString()}>{y}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>

              {loadingPYQ ? (
                <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
              ) : filteredPYQ.length > 0 ? (
                <div className="space-y-2 max-h-[400px] overflow-y-auto">
                  {filteredPYQ.map((q) => (
                    <div key={q.id} className="p-3 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between gap-3 hover:bg-white/10 transition-colors">
                      <div className="flex-1 min-w-0">
                        <div className="flex gap-2 mb-1">
                          <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded bg-primary/10 text-primary">{q.exam_type}</span>
                          <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded bg-white/5 text-muted-foreground">{q.year}</span>
                          {q.subject && <span className="text-[9px] font-bold uppercase px-1.5 py-0.5 rounded bg-white/5 text-muted-foreground">{q.subject}</span>}
                        </div>
                        <p className="text-[11px] text-muted-foreground line-clamp-2">{q.question_text}</p>
                      </div>
                      <div className="flex gap-1 shrink-0">
                        <Button variant="ghost" size="icon" className="h-7 w-7 rounded-lg text-muted-foreground hover:text-accent" onClick={() => startEditPYQ(q)}><Edit2 className="h-3 w-3" /></Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7 rounded-lg text-muted-foreground hover:text-destructive" onClick={() => handleDeletePYQ(q.id)}><Trash2 className="h-3 w-3" /></Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-16 text-muted-foreground text-sm">No PYQ questions found.</div>
              )}
            </TabsContent>

            <TabsContent value="add" className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Exam Type</Label>
                  <Select value={pyqForm.exam_type} onValueChange={(v) => setPyqForm({ ...pyqForm, exam_type: v })}>
                    <SelectTrigger className="glass border-white/10"><SelectValue /></SelectTrigger>
                    <SelectContent className="glass border-white/10">
                      {["NEET PG", "INICET", "USMLE Step 1", "USMLE Step 2", "FMGE"].map(e => <SelectItem key={e} value={e}>{e}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Year</Label>
                  <Input type="number" className="glass border-white/10" value={pyqForm.year} onChange={(e) => setPyqForm({ ...pyqForm, year: e.target.value })} />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Subject (optional)</Label>
                  <Input placeholder="e.g., Medicine" className="glass border-white/10" value={pyqForm.subject} onChange={(e) => setPyqForm({ ...pyqForm, subject: e.target.value })} />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Question Text</Label>
                  <Textarea className="glass border-white/10 min-h-[80px]" value={pyqForm.question_text} onChange={(e) => setPyqForm({ ...pyqForm, question_text: e.target.value })} />
                </div>
                <div className="space-y-2"><Label>Option A</Label><Input className="glass border-white/10" value={pyqForm.option1} onChange={(e) => setPyqForm({ ...pyqForm, option1: e.target.value })} /></div>
                <div className="space-y-2"><Label>Option B</Label><Input className="glass border-white/10" value={pyqForm.option2} onChange={(e) => setPyqForm({ ...pyqForm, option2: e.target.value })} /></div>
                <div className="space-y-2"><Label>Option C</Label><Input className="glass border-white/10" value={pyqForm.option3} onChange={(e) => setPyqForm({ ...pyqForm, option3: e.target.value })} /></div>
                <div className="space-y-2"><Label>Option D</Label><Input className="glass border-white/10" value={pyqForm.option4} onChange={(e) => setPyqForm({ ...pyqForm, option4: e.target.value })} /></div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Correct Answer Index (0-3)</Label>
                  <Select value={pyqForm.correct_answer_index} onValueChange={(v) => setPyqForm({ ...pyqForm, correct_answer_index: v })}>
                    <SelectTrigger className="glass border-white/10"><SelectValue /></SelectTrigger>
                    <SelectContent className="glass border-white/10">
                      <SelectItem value="0">Option A</SelectItem>
                      <SelectItem value="1">Option B</SelectItem>
                      <SelectItem value="2">Option C</SelectItem>
                      <SelectItem value="3">Option D</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Explanation</Label>
                  <Textarea className="glass border-white/10 min-h-[80px]" value={pyqForm.explanation} onChange={(e) => setPyqForm({ ...pyqForm, explanation: e.target.value })} />
                </div>
              </div>
              <div className="flex gap-2">
                {editingPYQId && (
                  <Button variant="ghost" onClick={() => { setEditingPYQId(null); setPyqForm({ exam_type: "NEET PG", year: new Date().getFullYear().toString(), subject: "", question_text: "", option1: "", option2: "", option3: "", option4: "", correct_answer_index: "0", explanation: "" }) }}>Cancel Edit</Button>
                )}
                <Button onClick={handleSavePYQ} disabled={uploading} className="flex-1">
                  {uploading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null} {editingPYQId ? "Update Question" : "Add Question"}
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="bulk" className="space-y-4">
              <div className="p-4 rounded-xl bg-primary/5 border border-primary/20 space-y-2">
                <p className="text-[10px] font-bold uppercase text-primary">Upload a Full Year's Paper</p>
                <p className="text-[9px] text-muted-foreground">Set the exam and year once below - every question in the CSV will be tagged with these.</p>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label className="text-xs">Exam Type</Label>
                  <Select value={pyqBulkExam} onValueChange={setPyqBulkExam}>
                    <SelectTrigger className="glass border-white/10"><SelectValue /></SelectTrigger>
                    <SelectContent className="glass border-white/10">
                      <SelectItem value="NEET PG">NEET PG</SelectItem>
                      <SelectItem value="INICET">INICET</SelectItem>
                      <SelectItem value="USMLE Step 1">USMLE Step 1</SelectItem>
                      <SelectItem value="USMLE Step 2">USMLE Step 2</SelectItem>
                      <SelectItem value="FMGE">FMGE</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Year</Label>
                  <Input type="number" className="glass border-white/10" value={pyqBulkYear} onChange={(e) => setPyqBulkYear(e.target.value)} />
                </div>
              </div>
              <div className="p-4 rounded-xl bg-primary/5 border border-primary/20 space-y-2">
                <p className="text-[10px] font-bold uppercase text-primary">Required CSV Headers</p>
                <p className="text-[9px] text-muted-foreground font-mono leading-tight">
                  subject, question_text, option1, option2, option3, option4, correct_answer_index, explanation
                </p>
              </div>
              <label className="flex items-center gap-3 p-3 rounded-xl bg-white/5 cursor-pointer">
                <input type="checkbox" checked={pyqAiSubjectFix} onChange={(e) => setPyqAiSubjectFix(e.target.checked)} className="h-4 w-4 rounded accent-primary" />
                <div>
                  <p className="text-xs font-bold">Use AI to fix subject names</p>
                  <p className="text-[10px] text-muted-foreground">Corrects typos and variants like "OBG", "obstetrics and gynaecolu", "FMT" to the proper subject name. Turn off if your CSV subjects are already exact.</p>
                </div>
              </label>
              <Input type="file" accept=".csv" className="glass border-white/10 cursor-pointer h-14 pt-4" onChange={handleImportPYQ} disabled={uploading} />
              {uploading && <div className="flex items-center gap-3 p-3 rounded-lg bg-white/5 animate-pulse"><Loader2 className="h-4 w-4 animate-spin text-primary" /><span className="text-[10px] font-bold uppercase">Importing...</span></div>}
            </TabsContent>
          </Tabs>
          <DialogFooter><Button variant="ghost" onClick={() => setIsUploadingPYQ(false)}>Close</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isManagingCases} onOpenChange={setIsManagingCases}>
        <DialogContent aria-describedby={undefined} className="glass border-white/10 max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Clinical Cases</DialogTitle>
          </DialogHeader>

          <div className="p-4 rounded-xl bg-primary/5 border border-primary/20 space-y-4">
            <h4 className="font-bold flex items-center gap-2 text-primary text-sm"><HelpCircle className="h-4 w-4" /> Generate a Clinical Case</h4>
            <div className="grid md:grid-cols-2 gap-3">
              <Input placeholder="Specialty, e.g. Cardiology" className="glass border-white/10" value={caseGenSpecialty} onChange={(e) => setCaseGenSpecialty(e.target.value)} />
              <Input placeholder="Topic, e.g. Acute MI" className="glass border-white/10" value={caseGenTopic} onChange={(e) => setCaseGenTopic(e.target.value)} />
            </div>
            <div className="flex items-center gap-3">
              <Select value={caseGenDifficulty} onValueChange={(v: any) => setCaseGenDifficulty(v)}>
                <SelectTrigger className="glass border-white/10 w-32"><SelectValue /></SelectTrigger>
                <SelectContent className="glass border-white/10">
                  <SelectItem value="easy">Easy</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="hard">Hard</SelectItem>
                </SelectContent>
              </Select>
              <Select value={caseGenTier} onValueChange={(v: any) => setCaseGenTier(v)}>
                <SelectTrigger className="glass border-white/10 w-32"><SelectValue /></SelectTrigger>
                <SelectContent className="glass border-white/10">
                  <SelectItem value="free">Free</SelectItem>
                  <SelectItem value="paid">Paid</SelectItem>
                </SelectContent>
              </Select>
              <Button onClick={handleGenerateCase} disabled={generatingCase} className="rounded-lg gap-2">
                {generatingCase ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />} Generate
              </Button>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-accent/5 border border-accent/20 space-y-3">
            <h4 className="font-bold flex items-center gap-2 text-accent text-sm"><Wand2 className="h-4 w-4" /> Ward Round: the 100 ready cases</h4>
            <p className="text-xs text-muted-foreground">Creates all 100 curated cases (Medicine, Surgery, OBG, Paediatrics and more) in one go. Already existing ones are skipped, so you can run it again to fill any gaps.</p>
            <div className="flex items-center gap-3 flex-wrap">
              <Button onClick={() => handleGenerate100(false)} disabled={!!batchRun?.running} className="rounded-lg gap-2">
                {batchRun?.running ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />} Generate 100 cases
              </Button>
              <Button onClick={() => handleGenerate100(true)} disabled={!!batchRun?.running} className="rounded-lg gap-2 bg-gradient-to-r from-rose-600 to-orange-500 text-white">
                {batchRun?.running ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />} Generate 200 expert cases
              </Button>
              {batchRun?.running && <Button variant="outline" className="rounded-lg" onClick={() => { batchStopRef.current = true }}>Stop</Button>}
              {batchRun && <span className="text-xs font-bold">{batchRun.done} / {batchRun.total} done{batchRun.failed ? " · " + batchRun.failed + " failed" : ""}{!batchRun.running ? " · finished" : ""}</span>}
            </div>
          </div>

          {draftCase && (
            <Card className="glass border-primary/30 border">
              <CardContent className="p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-sm uppercase tracking-widest text-primary">Draft Preview</h4>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="rounded-lg" onClick={() => setDraftCase(null)}>Discard</Button>
                    <Button size="sm" className="rounded-lg" onClick={handleSaveCase} disabled={savingCase}>
                      {savingCase ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null} Save Case
                    </Button>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Title</Label>
                  <Input className="glass border-white/10" value={draftCase.title} onChange={(e) => setDraftCase({ ...draftCase, title: e.target.value })} />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Opening Scenario</Label>
                  <Textarea className="glass border-white/10" rows={3} value={draftCase.stem} onChange={(e) => setDraftCase({ ...draftCase, stem: e.target.value })} />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Stages ({draftCase.stages.length})</Label>
                  <div className="space-y-2">
                    {draftCase.stages.map((s) => (
                      <div key={s.id} className="p-3 rounded-lg bg-white/5 text-xs">
                        <p className="font-bold uppercase text-primary mb-1">{s.type}</p>
                        <p className="text-muted-foreground mb-2">{s.prompt}</p>
                        <ul className="space-y-1">
                          {s.options.map((o) => (
                            <li key={o.id} className={o.outcome === 'optimal' ? 'text-green-400' : o.outcome === 'unsafe' ? 'text-red-400' : 'text-muted-foreground'}>
                              {o.label} <span className="opacity-60">({o.points} pts)</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Final Diagnosis</Label>
                  <Input className="glass border-white/10" value={draftCase.finalDiagnosis} onChange={(e) => setDraftCase({ ...draftCase, finalDiagnosis: e.target.value })} />
                </div>
              </CardContent>
            </Card>
          )}

          <div className="space-y-3">
            <h4 className="font-bold text-sm text-muted-foreground uppercase tracking-widest">Existing Cases</h4>
            {loadingCases ? (
              <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
            ) : (
              <div className="grid md:grid-cols-2 gap-4">
                {allCases.map((c: any) => (
                  <Card key={c.id} className="glass border-none">
                    <CardContent className="p-4 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <p className="font-bold text-sm truncate">{c.title}</p>
                        <p className="text-[10px] text-muted-foreground uppercase">{c.specialty} - {c.difficulty} - {c.tier}</p>
                      </div>
                      <Button variant="destructive" size="icon" className="h-8 w-8 rounded-lg shrink-0" onClick={() => handleDeleteCase(c)}><Trash2 className="h-4 w-4" /></Button>
                    </CardContent>
                  </Card>
                ))}
                {allCases.length === 0 && <div className="col-span-full text-center py-12 glass rounded-2xl text-muted-foreground text-sm">No cases yet. Generate one above.</div>}
              </div>
            )}
          </div>

          <DialogFooter><Button variant="ghost" onClick={() => setIsManagingCases(false)}>Close</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isManagingProfPyq} onOpenChange={setIsManagingProfPyq}>
        <DialogContent aria-describedby={undefined} className="glass border-white/10 max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Prof PYQ Answers</DialogTitle>
            <DialogDescription>University Prof exam questions with model answers - organized by subject and chapter.</DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="add">
            <TabsList className="glass border-none h-11 p-1 rounded-xl mb-4">
              <TabsTrigger value="add" className="rounded-lg">Add / Edit</TabsTrigger>
              <TabsTrigger value="bulk" className="rounded-lg">Bulk Import</TabsTrigger>
              <TabsTrigger value="manage" className="rounded-lg">Manage</TabsTrigger>
            </TabsList>

            <TabsContent value="add" className="space-y-4">
              <div className="grid md:grid-cols-2 gap-3">
                <Input placeholder="Subject, e.g. Anatomy" className="glass border-white/10" value={profPyqForm.subject} onChange={(e) => setProfPyqForm({ ...profPyqForm, subject: e.target.value })} />
                <Input placeholder="Chapter, e.g. Upper Limb" className="glass border-white/10" value={profPyqForm.chapter} onChange={(e) => setProfPyqForm({ ...profPyqForm, chapter: e.target.value })} />
              </div>
              <div className="grid md:grid-cols-2 gap-3">
                <Select value={profPyqForm.type} onValueChange={(v: any) => setProfPyqForm({ ...profPyqForm, type: v })}>
                  <SelectTrigger className="glass border-white/10"><SelectValue /></SelectTrigger>
                  <SelectContent className="glass border-white/10">
                    <SelectItem value="short_answer">Short Answer</SelectItem>
                    <SelectItem value="short_essay">Short Essay</SelectItem>
                    <SelectItem value="long_answer">Long Answer</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={profPyqForm.tier} onValueChange={(v: any) => setProfPyqForm({ ...profPyqForm, tier: v })}>
                  <SelectTrigger className="glass border-white/10"><SelectValue /></SelectTrigger>
                  <SelectContent className="glass border-white/10">
                    <SelectItem value="free">Free</SelectItem>
                    <SelectItem value="paid">Paid</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Textarea placeholder="Question" className="glass border-white/10" rows={2} value={profPyqForm.question} onChange={(e) => setProfPyqForm({ ...profPyqForm, question: e.target.value })} />
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-xs">Answer</Label>
                  <Button size="sm" variant="outline" className="rounded-lg gap-2" onClick={handleGenerateProfAnswer} disabled={generatingProfAnswer}>
                    {generatingProfAnswer ? <Loader2 className="h-3 w-3 animate-spin" /> : <Wand2 className="h-3 w-3" />} AI Assist
                  </Button>
                </div>
                <Textarea placeholder="Model answer" className="glass border-white/10" rows={8} value={profPyqForm.answer} onChange={(e) => setProfPyqForm({ ...profPyqForm, answer: e.target.value })} />
              </div>
              <div className="flex gap-2">
                {profPyqForm.id && (
                  <Button variant="outline" className="rounded-lg" onClick={() => setProfPyqForm({ id: null, subject: profPyqForm.subject, chapter: profPyqForm.chapter, type: profPyqForm.type, question: "", answer: "", tier: "free" })}>Cancel Edit</Button>
                )}
                <Button className="flex-1 rounded-lg" onClick={handleSaveProfPyq} disabled={savingProfPyq}>
                  {savingProfPyq ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null} {profPyqForm.id ? "Update Question" : "Save Question"}
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="bulk" className="space-y-4">
              <div className="p-4 rounded-xl bg-primary/5 border border-primary/20 space-y-2">
                <p className="text-[10px] font-bold uppercase text-primary">Required CSV Headers (no header row needed, just data in this column order)</p>
                <p className="text-[9px] text-muted-foreground font-mono leading-tight">
                  subject, chapter, type, question, answer, tier
                </p>
                <p className="text-[9px] text-muted-foreground">type: short_answer / short_essay / long_answer. tier: free / paid (optional, defaults to free)</p>
              </div>
              <Input type="file" accept=".csv" className="glass border-white/10 cursor-pointer h-14 pt-4" onChange={handleBulkImportProfPyq} disabled={uploadingProfPyqCsv} />
              {uploadingProfPyqCsv && <div className="flex items-center gap-3 p-3 rounded-lg bg-white/5 animate-pulse"><Loader2 className="h-4 w-4 animate-spin text-primary" /><span className="text-[10px] font-bold uppercase">Importing...</span></div>}
            </TabsContent>

            <TabsContent value="manage" className="space-y-3">
              {loadingProfPyq ? (
                <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
              ) : (
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {allProfPyq.map((item: any) => (
                    <Card key={item.id} className="glass border-none">
                      <CardContent className="p-4 flex items-center justify-between gap-3">
                        <div className="min-w-0">
                          <p className="font-medium text-sm truncate">{item.question}</p>
                          <p className="text-[10px] text-muted-foreground uppercase">{item.subject} - {item.chapter} - {item.type} - {item.tier}</p>
                        </div>
                        <div className="flex gap-2 shrink-0">
                          <Button variant="outline" size="icon" className="h-8 w-8 rounded-lg" onClick={() => handleEditProfPyq(item)}><Edit2 className="h-4 w-4" /></Button>
                          <Button variant="destructive" size="icon" className="h-8 w-8 rounded-lg" onClick={() => handleDeleteProfPyq(item)}><Trash2 className="h-4 w-4" /></Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  {allProfPyq.length === 0 && <div className="text-center py-12 glass rounded-2xl text-muted-foreground text-sm">No questions yet.</div>}
                </div>
              )}
            </TabsContent>
          </Tabs>

          <DialogFooter><Button variant="ghost" onClick={() => setIsManagingProfPyq(false)}>Close</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isManagingNotePacks} onOpenChange={setIsManagingNotePacks}>
        <DialogContent aria-describedby={undefined} className="glass border-white/10 max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Notes Packs</DialogTitle>
            <DialogDescription>Sell complete year-wise notes as a one-time purchase. PDFs are stored privately and only viewable inside the app by buyers.</DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="flex gap-2 p-1 rounded-xl bg-white/5 w-fit">
              <button type="button" onClick={() => setNotePackForm({ ...notePackForm, packType: "single" })} className={`px-4 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wide transition-all ${notePackForm.packType === "single" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>Single Year</button>
              <button type="button" onClick={() => setNotePackForm({ ...notePackForm, packType: "combo" })} className={`px-4 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wide transition-all ${notePackForm.packType === "combo" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}>Combo</button>
            </div>

            <div className="grid md:grid-cols-2 gap-3">
              {notePackForm.packType === "single" ? (
                <Select value={notePackForm.year} onValueChange={(v: any) => setNotePackForm({ ...notePackForm, year: v })}>
                  <SelectTrigger className="glass border-white/10"><SelectValue /></SelectTrigger>
                  <SelectContent className="glass border-white/10">
                    <SelectItem value="1st">1st Year</SelectItem>
                    <SelectItem value="2nd">2nd Year</SelectItem>
                    <SelectItem value="3rd">3rd Year</SelectItem>
                  </SelectContent>
                </Select>
              ) : <div />}
              <Input type="number" placeholder="Price (Rs)" className="glass border-white/10" value={notePackForm.price} onChange={(e) => setNotePackForm({ ...notePackForm, price: e.target.value })} />
            </div>
            <Input placeholder={notePackForm.packType === "combo" ? "Title, e.g. All 3 Years Bundle" : "Title, e.g. 1st Year Complete Notes"} className="glass border-white/10" value={notePackForm.title} onChange={(e) => setNotePackForm({ ...notePackForm, title: e.target.value })} />
            <Textarea placeholder="Description shown in the Store" className="glass border-white/10" rows={2} value={notePackForm.description} onChange={(e) => setNotePackForm({ ...notePackForm, description: e.target.value })} />

            {notePackForm.packType === "single" ? (
              <div className="space-y-2">
                <Label className="text-xs">{notePackForm.id ? "Replace PDF (optional)" : "PDF File"}</Label>
                <Input type="file" accept=".pdf" className="glass border-white/10 cursor-pointer h-14 pt-4" onChange={(e) => setNotePackForm({ ...notePackForm, file: e.target.files?.[0] || null })} />
              </div>
            ) : (
              <div className="space-y-2">
                <Label className="text-xs">Select packs to include (2 or more)</Label>
                <div className="space-y-1 max-h-48 overflow-y-auto p-2 rounded-xl bg-white/5">
                  {allNotePacks.filter((p: any) => p.packType !== "combo").map((p: any) => {
                    const checked = notePackForm.includedPackIds.includes(p.id)
                    return (
                      <label key={p.id} className="flex items-center gap-2 p-2 rounded-lg hover:bg-white/5 cursor-pointer text-sm">
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={(e) => {
                            const next = e.target.checked
                              ? [...notePackForm.includedPackIds, p.id]
                              : notePackForm.includedPackIds.filter((id) => id !== p.id)
                            setNotePackForm({ ...notePackForm, includedPackIds: next })
                          }}
                        />
                        {p.title} <span className="text-muted-foreground text-xs">({p.year} Year)</span>
                      </label>
                    )
                  })}
                  {allNotePacks.filter((p: any) => p.packType !== "combo").length === 0 && (
                    <p className="text-xs text-muted-foreground p-2">Create some Single Year packs first.</p>
                  )}
                </div>
              </div>
            )}

            <div className="flex gap-2">
              {notePackForm.id && (
                <Button variant="outline" className="rounded-lg" onClick={() => setNotePackForm(emptyNotePackForm)}>Cancel Edit</Button>
              )}
              <Button className="flex-1 rounded-lg" onClick={handleSaveNotePack} disabled={uploadingNotePack}>
                {uploadingNotePack ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null} {notePackForm.id ? "Update Notes Pack" : "Create Notes Pack"}
              </Button>
            </div>
          </div>

          <div className="space-y-3 pt-2">
            <h4 className="font-bold text-sm text-muted-foreground uppercase tracking-widest">Existing Packs</h4>
            {loadingNotePacks ? (
              <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
            ) : (
              <div className="space-y-2">
                {allNotePacks.map((item: any) => (
                  <Card key={item.id} className="glass border-none">
                    <CardContent className="p-4 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <p className="font-medium text-sm truncate">{item.title}</p>
                        <p className="text-[10px] text-muted-foreground uppercase">{item.year} Year - Rs {item.price}</p>
                      </div>
                      <div className="flex gap-2 shrink-0">
                        <Button variant="outline" size="icon" className="h-8 w-8 rounded-lg" onClick={() => handleEditNotePack(item)}><Edit2 className="h-4 w-4" /></Button>
                        <Button variant="destructive" size="icon" className="h-8 w-8 rounded-lg" onClick={() => handleDeleteNotePack(item)}><Trash2 className="h-4 w-4" /></Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                {allNotePacks.length === 0 && <div className="text-center py-12 glass rounded-2xl text-muted-foreground text-sm">No Notes Packs yet.</div>}
              </div>
            )}
          </div>

          <DialogFooter><Button variant="ghost" onClick={() => setIsManagingNotePacks(false)}>Close</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isManagingBanner} onOpenChange={setIsManagingBanner}>
        <DialogContent aria-describedby={undefined} className="glass border-white/10 max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Dashboard Ads</DialogTitle>
            <DialogDescription>Promo banners shown at the top of the dashboard. Multiple active ads rotate automatically like a carousel.</DialogDescription>
          </DialogHeader>

          <div className="space-y-3">
            <Label className="text-xs text-muted-foreground uppercase tracking-widest">Existing Ads</Label>
            {loadingBanner ? (
              <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
            ) : (
              <div className="space-y-2">
                {allBanners.map((item: any) => (
                  <Card key={item.id} className="glass border-none">
                    <CardContent className="p-3 flex items-center justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <p className="font-medium text-sm truncate">{item.headline}</p>
                        <p className="text-[10px] text-muted-foreground">{item.enabled ? "Active" : "Disabled"}</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleToggleBannerEnabled(item)}
                        className={`w-9 h-5 rounded-full transition-colors relative shrink-0 ${item.enabled ? "bg-primary" : "bg-white/10"}`}
                      >
                        <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-white transition-transform ${item.enabled ? "translate-x-4" : "translate-x-0.5"}`} />
                      </button>
                      <Button variant="outline" size="icon" className="h-8 w-8 rounded-lg shrink-0" onClick={() => handleEditBanner(item)}><Edit2 className="h-4 w-4" /></Button>
                      <Button variant="destructive" size="icon" className="h-8 w-8 rounded-lg shrink-0" onClick={() => handleDeleteBanner(item)}><Trash2 className="h-4 w-4" /></Button>
                    </CardContent>
                  </Card>
                ))}
                {allBanners.length === 0 && <div className="text-center py-8 glass rounded-2xl text-muted-foreground text-sm">No ads yet. Create one below.</div>}
              </div>
            )}
          </div>

          <div className="space-y-4 pt-2 border-t border-white/5">
            <Label className="text-xs text-muted-foreground uppercase tracking-widest">{bannerForm.id ? "Edit Ad" : "New Ad"}</Label>

            <div className="p-4 rounded-xl bg-primary/5 border border-primary/20 space-y-3">
              <p className="text-[10px] font-bold uppercase text-primary flex items-center gap-1.5"><Sparkles className="h-3 w-3" /> Draft with AI (optional)</p>
              <div className="flex gap-2">
                <Input placeholder="What do you want to advertise? e.g. '2nd year notes combo, 50% off this week'" className="glass border-white/10" value={bannerGenPrompt} onChange={(e) => setBannerGenPrompt(e.target.value)} />
                <Button onClick={handleGenerateBannerAI} disabled={generatingBanner} className="rounded-lg gap-2 shrink-0">
                  {generatingBanner ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />} Draft
                </Button>
              </div>
            </div>

            <div className="flex items-center justify-between p-3 rounded-xl bg-white/5">
              <Label className="text-sm">Active</Label>
              <button
                type="button"
                onClick={() => setBannerForm({ ...bannerForm, enabled: !bannerForm.enabled })}
                className={`w-11 h-6 rounded-full transition-colors relative ${bannerForm.enabled ? "bg-primary" : "bg-white/10"}`}
              >
                <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform ${bannerForm.enabled ? "translate-x-5" : "translate-x-0.5"}`} />
              </button>
            </div>

            <div className="space-y-2">
              <Label className="text-xs">Badge Text</Label>
              <Input className="glass border-white/10" value={bannerForm.badgeText} onChange={(e) => setBannerForm({ ...bannerForm, badgeText: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label className="text-xs">Headline</Label>
              <Input className="glass border-white/10" value={bannerForm.headline} onChange={(e) => setBannerForm({ ...bannerForm, headline: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label className="text-xs">Highlighted portion (must match the end of the headline exactly)</Label>
              <Input className="glass border-white/10" value={bannerForm.headlineHighlight} onChange={(e) => setBannerForm({ ...bannerForm, headlineHighlight: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label className="text-xs">Bullet Points</Label>
              {bannerForm.bullets.map((b: string, i: number) => (
                <Input key={i} className="glass border-white/10 mb-2" value={b} onChange={(e) => {
                  const next = [...bannerForm.bullets]
                  next[i] = e.target.value
                  setBannerForm({ ...bannerForm, bullets: next })
                }} />
              ))}
            </div>
            <div className="grid md:grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label className="text-xs">Button Text</Label>
                <Input className="glass border-white/10" value={bannerForm.buttonText} onChange={(e) => setBannerForm({ ...bannerForm, buttonText: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label className="text-xs">Button Link</Label>
                <Input className="glass border-white/10" value={bannerForm.buttonLink} onChange={(e) => setBannerForm({ ...bannerForm, buttonLink: e.target.value })} />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-xs text-muted-foreground uppercase tracking-widest">Live Preview</Label>
              <div className="relative overflow-hidden rounded-2xl border border-primary/30 p-5" style={{ background: "linear-gradient(135deg, rgba(124,58,237,0.18), rgba(168,85,247,0.08) 40%, rgba(0,0,0,0) 70%)" }}>
                <div className="absolute -top-10 -right-10 h-32 w-32 rounded-full bg-primary/20 blur-3xl pointer-events-none" />
                <div className="relative space-y-2">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-primary/20 text-primary text-[10px] font-bold uppercase tracking-widest">
                    <Sparkles className="h-3 w-3" /> {bannerForm.badgeText}
                  </span>
                  <h3 className="text-lg font-bold leading-tight">
                    {bannerForm.headline.replace(bannerForm.headlineHighlight, "").trim()}{" "}
                    <span className="text-primary">{bannerForm.headlineHighlight}</span>
                  </h3>
                  <div className="flex flex-wrap gap-x-4 gap-y-1">
                    {bannerForm.bullets.map((b: string, i: number) => (
                      <span key={i} className="flex items-center gap-1 text-xs text-muted-foreground"><CheckCircle2 className="h-3 w-3 text-green-400" /> {b}</span>
                    ))}
                  </div>
                  <Button size="sm" className="rounded-lg gap-2 font-bold mt-2">{bannerForm.buttonText} <ArrowRight className="h-3 w-3" /></Button>
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              {bannerForm.id && (
                <Button variant="outline" className="rounded-lg" onClick={() => setBannerForm(emptyBannerForm)}>Cancel Edit</Button>
              )}
              <Button className="flex-1 rounded-lg" onClick={handleSaveBanner} disabled={savingBanner}>
                {savingBanner ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null} {bannerForm.id ? "Update Ad" : "Create Ad"}
              </Button>
            </div>
          </div>

          <DialogFooter>
            <Button variant="ghost" onClick={() => setIsManagingBanner(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isAddingProduct} onOpenChange={setIsAddingProduct}>
        <DialogContent aria-describedby={undefined} className="glass border-white/10 max-w-lg">
          <DialogHeader><DialogTitle>Add New Product</DialogTitle></DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Title</Label>
              <Input placeholder="e.g., NEET PG Notes Pack 2024" className="glass border-white/10"
                value={productForm.title} onChange={e => setProductForm({...productForm, title: e.target.value})} />
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea placeholder="Brief description of the product..." className="glass border-white/10"
                value={productForm.description} onChange={e => setProductForm({...productForm, description: e.target.value})} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Price (₹)</Label>
                <Input type="number" placeholder="499" className="glass border-white/10"
                  value={productForm.price} onChange={e => setProductForm({...productForm, price: e.target.value})} />
              </div>
              <div className="space-y-2">
                <Label>Category</Label>
                <Select value={productForm.category} onValueChange={v => setProductForm({...productForm, category: v})}>
                  <SelectTrigger className="glass border-white/10"><SelectValue /></SelectTrigger>
                  <SelectContent className="glass border-white/10">
                    {["Notes Pack", "Question Bank", "Flashcards", "Video Pack", "Combo Pack"].map(c => (
                      <SelectItem key={c} value={c}>{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Buy Link (WhatsApp/Instamojo URL)</Label>
              <Input placeholder="https://wa.me/91..." className="glass border-white/10"
                value={productForm.buy_link} onChange={e => setProductForm({...productForm, buy_link: e.target.value})} />
            </div>
            <div className="space-y-2">
              <Label>Product Image URL (optional)</Label>
              <Input placeholder="https://..." className="glass border-white/10"
                value={productForm.image_url} onChange={e => setProductForm({...productForm, image_url: e.target.value})} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setIsAddingProduct(false)}>Cancel</Button>
            <Button onClick={handleAddProduct} disabled={uploading}>
              {uploading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null} Add Product
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add/Edit Question Dialog */}
      <Dialog open={isEditingQuestion} onOpenChange={setIsEditingQuestion}>
        <DialogContent className="glass border-white/10 max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{qbankForm.id ? 'Edit Clinical Case' : 'Add New Clinical Case'}</DialogTitle>
          </DialogHeader>
          <div className="grid md:grid-cols-2 gap-4 py-4">
            <div className="space-y-2">
              <Label>Subject</Label>
              <Select onValueChange={(v) => setQbankForm({ ...qbankForm, subjectId: v })} value={qbankForm.subjectId}>
                <SelectTrigger className="glass border-white/10">
                  <SelectValue placeholder="Select Subject" />
                </SelectTrigger>
                <SelectContent className="glass border-white/10">
                  {subjects?.map((s: any) => <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Unit Title</Label>
              <Input placeholder="e.g., Neonatology" className="glass border-white/10" value={qbankForm.unit_title} onChange={(e) => setQbankForm({ ...qbankForm, unit_title: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Topic Title</Label>
              <Input placeholder="e.g., Routine Newborn Care" className="glass border-white/10" value={qbankForm.topic_title} onChange={(e) => setQbankForm({ ...qbankForm, topic_title: e.target.value })} />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label>Question Vignette</Label>
              <Textarea placeholder="Describe the clinical presentation..." className="glass border-white/10 min-h-[100px]" value={qbankForm.question_text} onChange={(e) => setQbankForm({ ...qbankForm, question_text: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Option A</Label>
              <Input className="glass border-white/10" value={qbankForm.option1} onChange={(e) => setQbankForm({ ...qbankForm, option1: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Option B</Label>
              <Input className="glass border-white/10" value={qbankForm.option2} onChange={(e) => setQbankForm({ ...qbankForm, option2: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Option C</Label>
              <Input className="glass border-white/10" value={qbankForm.option3} onChange={(e) => setQbankForm({ ...qbankForm, option3: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Option D</Label>
              <Input className="glass border-white/10" value={qbankForm.option4} onChange={(e) => setQbankForm({ ...qbankForm, option4: e.target.value })} />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label>Correct Answer Index (0-3)</Label>
              <Select onValueChange={(v) => setQbankForm({ ...qbankForm, correct_answer_index: v })} value={qbankForm.correct_answer_index}>
                <SelectTrigger className="glass border-white/10">
                  <SelectValue placeholder="Select Index" />
                </SelectTrigger>
                <SelectContent className="glass border-white/10">
                  <SelectItem value="0">Option A</SelectItem>
                  <SelectItem value="1">Option B</SelectItem>
                  <SelectItem value="2">Option C</SelectItem>
                  <SelectItem value="3">Option D</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label>High-Yield Explanation</Label>
              <Textarea placeholder="Explain the clinical logic..." className="glass border-white/10 min-h-[100px]" value={qbankForm.explanation} onChange={(e) => setQbankForm({ ...qbankForm, explanation: e.target.value })} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setIsEditingQuestion(false)}>Cancel</Button>
            <Button onClick={handleSaveQuestion} disabled={uploading}>{uploading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null} Save Case</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Import Dialog */}
      <Dialog open={isUploadingQBank} onOpenChange={setIsUploadingQBank}>
        <DialogContent className="glass border-white/10 max-w-md">
          <DialogHeader>
            <DialogTitle>Bulk QBank Import</DialogTitle>
            <DialogDescription>Select a formatted CSV file to import cases for {activeSubject}.</DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-4">
             <div className="p-4 rounded-xl bg-primary/5 border border-primary/20 space-y-2">
                <p className="text-[10px] font-bold uppercase text-primary">Required CSV Headers</p>
                <p className="text-[9px] text-muted-foreground font-mono leading-tight">
                  unit_title, topic_title, question_text, option1, option2, option3, option4, correct_answer_index, explanation
                </p>
             </div>
             <div className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/5">
                <div className="space-y-0.5">
                  <Label className="text-xs font-bold">AI Auto-Fix</Label>
                  <p className="text-[10px] text-muted-foreground">Checks for column shifts, wrong answers &amp; missing explanations before import.</p>
                </div>
                <Switch checked={useAiFixer} onCheckedChange={setUseAiFixer} />
             </div>
             <div className="space-y-2">
                <Label>Clinical Data File (.csv)</Label>
                <div className="relative group">
                   <Input 
                    type="file" 
                    accept=".csv" 
                    className="glass border-white/10 cursor-pointer h-14 pt-4 pr-10" 
                    onChange={handleImportCSV}
                    disabled={uploading}/>
                   <FileDown className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground opacity-20 group-hover:opacity-100 transition-opacity" />
                </div>
             </div>
             {uploading && (
               <div className="flex items-center gap-3 p-3 rounded-lg bg-white/5 border border-white/5 animate-pulse">
                  <Loader2 className="h-4 w-4 animate-spin text-primary" />
                  <span className="text-[10px] font-bold uppercase tracking-widest">Processing Clinical Pool...</span>
               </div>
             )}
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setIsUploadingQBank(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {aiFixing && (
        <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black/80 backdrop-blur-sm gap-6 p-8">
          <div className="glass border border-white/10 rounded-2xl p-8 max-w-md w-full space-y-6">
            <div className="flex items-center gap-4">
              <Loader2 className="h-8 w-8 text-primary animate-spin shrink-0" />
              <div>
                <p className="text-foreground font-bold text-lg">AI is fixing your CSV</p>
                <p className="text-muted-foreground text-sm">{aiFixProgress.message || 'Analysing questions...'}</p>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>{aiFixProgress.done} of {aiFixProgress.total} questions</span>
                <span>{aiFixProgress.total > 0 ? Math.round((aiFixProgress.done / aiFixProgress.total) * 100) : 0}%</span>
              </div>
              <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary rounded-full transition-all duration-300"
                  style={{ width: aiFixProgress.total > 0 ? (aiFixProgress.done / aiFixProgress.total * 100) + '%' : '0%' }}
                />
              </div>
            </div>
            <p className="text-[11px] text-muted-foreground text-center">Fixing column shifts, wrong answers and missing explanations</p>
          </div>
        </div>
      )}

      {/* CSV Organizer Dialog */}
      <Dialog open={showCsvOrganizer} onOpenChange={setShowCsvOrganizer}>
        <DialogContent className="glass border-white/10 max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Organise Import — {activeSubject}</DialogTitle>
            <DialogDescription>
              {csvParsedTopics.reduce((s: number, t: any) => s + t.questions.length, 0)} questions across {csvParsedTopics.length} topics detected. Rename topics, assign units, and reorder before importing.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            {aiFixLog.length > 0 && (
              <div className="rounded-xl border border-yellow-500/20 bg-yellow-500/5 p-3 space-y-2">
                <button onClick={() => setShowFixLog((v: boolean) => !v)} className="flex items-center gap-2 text-xs font-bold text-yellow-400 uppercase tracking-widest w-full">
                  <AlertTriangle className="h-3.5 w-3.5" />
                  AI Auto-Fixed {aiFixLog.length} issues
                  <ChevronDown className={`h-3 w-3 ml-auto transition-transform ${showFixLog ? 'rotate-180' : ''}`} />
                </button>
                {showFixLog && (
                  <div className="space-y-1 max-h-40 overflow-y-auto">
                    {aiFixLog.map((log: any, i: number) => (
                      <div key={i} className="text-[10px] text-muted-foreground bg-white/5 rounded-lg px-2 py-1 flex gap-2">
                        <span className="text-yellow-400 font-bold shrink-0">Row {log.row} [{log.field}]</span>
                        <span className="line-through opacity-50 truncate">{log.before}</span>
                        <span className="text-green-400 shrink-0">→</span>
                        <span className="truncate">{log.after}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
            <div className="p-4 rounded-xl bg-primary/5 border border-primary/20 space-y-3">
              <Label className="text-xs font-bold uppercase tracking-widest text-primary">Default Unit Name (applies to all topics)</Label>
              <Input
                placeholder="e.g., General Anatomy, Unit 1..."
                className="glass border-white/10"
                value={csvUnitName}
                onChange={(e: any) => setCsvUnitName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <Checkbox
                    checked={csvParsedTopics.length > 0 && selectedCsvTopics.size === csvParsedTopics.length}
                    onCheckedChange={(checked: boolean) => {
                      if (checked) setSelectedCsvTopics(new Set(csvParsedTopics.map((t: any) => t.order)))
                      else setSelectedCsvTopics(new Set())
                    }}
                  />
                  <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Topics ({csvParsedTopics.length})</Label>
                </div>
                {selectedCsvTopics.size > 0 && (
                  <div className="flex items-center gap-2">
                    <Input
                      placeholder="Unit name for selected..."
                      value={bulkUnitInput}
                      onChange={(e) => setBulkUnitInput(e.target.value)}
                      className="glass border-white/10 h-8 text-xs w-48"
                    />
                    <Button
                      size="sm"
                      className="h-8 text-xs"
                      disabled={!bulkUnitInput.trim()}
                      onClick={() => {
                        setCsvParsedTopics((prev: any[]) => prev.map((t: any) =>
                          selectedCsvTopics.has(t.order) ? { ...t, unitName: bulkUnitInput.trim() } : t
                        ))
                        setSelectedCsvTopics(new Set())
                        setBulkUnitInput("")
                      }}
                    >
                      Assign Unit to {selectedCsvTopics.size} Topic(s)
                    </Button>
                  </div>
                )}
              </div>
              <div className="space-y-2">
                {[...csvParsedTopics].sort((a: any, b: any) => a.order - b.order).map((topic: any, idx: number) => (
                  <div key={idx} className="glass rounded-xl border border-white/5 p-3 space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="flex flex-col gap-0.5 shrink-0">
                        <button
                          onClick={() => {
                            if (idx === 0) return
                            setCsvParsedTopics((prev: any[]) => {
                              const updated = [...prev].sort((a,b) => a.order - b.order)
                              const temp = updated[idx].order
                              updated[idx].order = updated[idx-1].order
                              updated[idx-1].order = temp
                              return [...updated]
                            })
                          }}
                          disabled={idx === 0}
                          className="p-0.5 text-muted-foreground hover:text-foreground disabled:opacity-20 transition-colors"
                        >
                          <ChevronUp className="h-3 w-3" />
                        </button>
                        <button
                          onClick={() => {
                            if (idx === csvParsedTopics.length - 1) return
                            setCsvParsedTopics((prev: any[]) => {
                              const updated = [...prev].sort((a,b) => a.order - b.order)
                              const temp = updated[idx].order
                              updated[idx].order = updated[idx+1].order
                              updated[idx+1].order = temp
                              return [...updated]
                            })
                          }}
                          disabled={idx === csvParsedTopics.length - 1}
                          className="p-0.5 text-muted-foreground hover:text-foreground disabled:opacity-20 transition-colors"
                        >
                          <ChevronDown className="h-3 w-3" />
                        </button>
                      </div>
                      <Checkbox
                        checked={selectedCsvTopics.has(topic.order)}
                        onCheckedChange={(checked: boolean) => {
                          setSelectedCsvTopics((prev) => {
                            const next = new Set(prev)
                            if (checked) next.add(topic.order)
                            else next.delete(topic.order)
                            return next
                          })
                        }}
                      />
                      <GripVertical className="h-4 w-4 text-muted-foreground/30 shrink-0" />
                      <div className="flex-1 min-w-0">
                        <Input
                          value={topic.topicName}
                          onChange={(e: any) => setCsvParsedTopics((prev: any[]) => prev.map((t: any) =>
                            t.order === topic.order ? { ...t, topicName: e.target.value } : t
                          ))}
                          className="glass border-white/10 h-8 text-sm font-medium"
                          placeholder="Topic name..."
                        />
                      </div>
                      <span className="text-[10px] font-bold text-muted-foreground bg-white/5 px-2 py-1 rounded-lg shrink-0">
                        {topic.questions.length} Qs
                      </span>
                      <button
                        onClick={() => setCsvParsedTopics((prev: any[]) => prev.filter((t: any) => t.order !== topic.order))}
                        className="text-muted-foreground hover:text-red-400 transition-colors shrink-0"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                    <div className="pl-9 flex items-center gap-2">
                      <span className="text-[10px] text-muted-foreground whitespace-nowrap">Unit override:</span>
                      <Input
                        value={topic.unitName}
                        onChange={(e: any) => setCsvParsedTopics((prev: any[]) => prev.map((t: any) =>
                          t.order === topic.order ? { ...t, unitName: e.target.value } : t
                        ))}
                        placeholder={csvUnitName || "uses default unit above"}
                        className="glass border-white/10 h-7 text-xs"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="p-3 rounded-xl bg-accent/5 border border-accent/20 flex items-center gap-3">
              <CheckCircle2 className="h-4 w-4 text-accent shrink-0" />
              <p className="text-xs text-muted-foreground">
                Ready to import <span className="font-bold text-foreground">{csvParsedTopics.reduce((s: number, t: any) => s + t.questions.length, 0)} questions</span> across <span className="font-bold text-foreground">{csvParsedTopics.length} topics</span> into <span className="font-bold text-foreground">{activeSubject}</span>.
              </p>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => setShowCsvOrganizer(false)}>Cancel</Button>
            <Button onClick={handleConfirmImport} disabled={uploading} className="gap-2">
              {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
              {uploading ? "Importing..." : "Confirm Import"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reassign Topic Unit Dialog */}
      {reassignTopic && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="glass border border-white/10 rounded-2xl p-6 max-w-md w-full space-y-4">
            <div>
              <h3 className="font-bold text-base">Move Topic to Unit</h3>
              <p className="text-xs text-muted-foreground mt-1">
                Moving <span className="text-foreground font-semibold">{reassignTopic.topic}</span> from <span className="text-muted-foreground">{reassignTopic.currentUnit}</span>
              </p>
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">New Unit Name</Label>
              <Input
                value={reassignUnitInput}
                onChange={(e) => setReassignUnitInput(e.target.value)}
                placeholder="e.g., Unit I — Cell Biology"
                className="glass border-white/10"
                autoFocus
              />
              <p className="text-[10px] text-muted-foreground">Type an existing unit name to merge, or a new name to create a new unit.</p>
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="ghost" onClick={() => setReassignTopic(null)}>Cancel</Button>
              <Button
                onClick={() => handleReassignTopicUnit(reassignTopic.topic, reassignUnitInput)}
                disabled={reassigning || !reassignUnitInput.trim()}
                className="gap-2"
              >
                {reassigning ? <Loader2 className="h-4 w-4 animate-spin" /> : <Edit2 className="h-4 w-4" />}
                {reassigning ? 'Moving...' : 'Move Topic'}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Add Topic Modal */}
      <Dialog open={isAddingTopic} onOpenChange={setIsAddingTopic}>
        <DialogContent className="glass border-white/10 max-w-lg">
          <DialogHeader>
            <DialogTitle>Publish New Study Note</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Subject</Label>
              <Select value={topicForm.subjectId} onValueChange={(v) => setTopicForm({ ...topicForm, subjectId: v })}>
                <SelectTrigger className="glass border-white/10">
                  <SelectValue placeholder="Select Subject" />
                </SelectTrigger>
                <SelectContent className="glass border-white/10">
                  {subjects?.map((s: any) => <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Unit Name</Label>
              <Input placeholder="e.g., CNS Anatomy" className="glass border-white/10" value={topicForm.unitName} onChange={(e) => setTopicForm({ ...topicForm, unitName: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Note Title</Label>
              <Input placeholder="e.g., Ventricular System" className="glass border-white/10" value={topicForm.title} onChange={(e) => setTopicForm({ ...topicForm, title: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>PDF Document</Label>
              <Input type="file" accept=".pdf" className="glass border-white/10 cursor-pointer" onChange={(e) => setTopicForm({ ...topicForm, file: e.target.files?.[0] || null })} />
            </div>
            <div className="space-y-2">
              <Label>Access Tier</Label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setTopicForm({ ...topicForm, tier: "free" })}
                  className={`p-3 rounded-xl border text-sm font-bold transition-all ${topicForm.tier === 'free' ? 'bg-green-500/10 border-green-500/40 text-green-400' : 'bg-white/5 border-white/10 text-muted-foreground'}`}
                >
                  🆓 Free
                </button>
                <button
                  type="button"
                  onClick={() => setTopicForm({ ...topicForm, tier: "paid" })}
                  className={`p-3 rounded-xl border text-sm font-bold transition-all ${topicForm.tier === 'paid' ? 'bg-primary/10 border-primary/40 text-primary' : 'bg-white/5 border-white/10 text-muted-foreground'}`}
                >
                  👑 Paid
                </button>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setIsAddingTopic(false)}>Cancel</Button>
            <Button onClick={handleAddTopic} disabled={uploading}>{uploading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null} Publish Note</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Video Modal */}
      <Dialog open={isAddingVideo} onOpenChange={setIsAddingVideo}>
        <DialogContent className="glass border-white/10 max-w-lg">
          <DialogHeader>
            <DialogTitle>Add Curriculum Video</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Subject</Label>
              <Select value={videoForm.subjectId} onValueChange={(v) => setVideoForm({ ...videoForm, subjectId: v })}>
                <SelectTrigger className="glass border-white/10">
                  <SelectValue placeholder="Select Subject" />
                </SelectTrigger>
                <SelectContent className="glass border-white/10">
                  {subjects?.map((s: any) => <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Unit Name</Label>
              <Input placeholder="e.g., Physiology of Respiration" className="glass border-white/10" value={videoForm.unitName} onChange={(e) => setVideoForm({ ...videoForm, unitName: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Lecture Title</Label>
              <Input placeholder="e.g., Gas Exchange Mechanisms" className="glass border-white/10" value={videoForm.title} onChange={(e) => setVideoForm({ ...videoForm, title: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>YouTube URL</Label>
              <Input placeholder="https://youtube.com/watch?v=..." className="glass border-white/10" value={videoForm.url} onChange={(e) => setVideoForm({ ...videoForm, url: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Access Tier</Label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setVideoForm({ ...videoForm, tier: "free" })}
                  className={`p-3 rounded-xl border text-sm font-bold transition-all ${videoForm.tier === 'free' ? 'bg-green-500/10 border-green-500/40 text-green-400' : 'bg-white/5 border-white/10 text-muted-foreground'}`}
                >
                  🆓 Free
                </button>
                <button
                  type="button"
                  onClick={() => setVideoForm({ ...videoForm, tier: "paid" })}
                  className={`p-3 rounded-xl border text-sm font-bold transition-all ${videoForm.tier === 'paid' ? 'bg-primary/10 border-primary/40 text-primary' : 'bg-white/5 border-white/10 text-muted-foreground'}`}
                >
                  👑 Paid
                </button>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setIsAddingVideo(false)}>Cancel</Button>
            <Button onClick={handleAddVideo} disabled={uploading}>{uploading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null} Add Video</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Mindmap Modal */}
      <Dialog open={isAddingMindmap} onOpenChange={setIsAddingMindmap}>
        <DialogContent className="glass border-white/10 max-w-lg">
          <DialogHeader>
            <DialogTitle>Upload Subject Mindmap</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Subject</Label>
              <Select value={mindmapForm.subjectId} onValueChange={(v) => setMindmapForm({ ...mindmapForm, subjectId: v })}>
                <SelectTrigger className="glass border-white/10">
                  <SelectValue placeholder="Select Subject" />
                </SelectTrigger>
                <SelectContent className="glass border-white/10">
                  {subjects?.map((s: any) => <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Unit Name</Label>
              <Input placeholder="e.g., Unit I" className="glass border-white/10" value={mindmapForm.unitName} onChange={(e) => setMindmapForm({ ...mindmapForm, unitName: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Mindmap Title</Label>
              <Input placeholder="e.g., Coagulation Cascade" className="glass border-white/10" value={mindmapForm.title} onChange={(e) => setMindmapForm({ ...mindmapForm, title: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Image File (Visual Map)</Label>
              <Input type="file" accept="image/*" className="glass border-white/10 cursor-pointer" onChange={(e) => setMindmapForm({ ...mindmapForm, file: e.target.files?.[0] || null })} />
            </div>
            <div className="space-y-2">
              <Label>Access Tier</Label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setMindmapForm({ ...mindmapForm, tier: "free" })}
                  className={`p-3 rounded-xl border text-sm font-bold transition-all ${mindmapForm.tier === 'free' ? 'bg-green-500/10 border-green-500/40 text-green-400' : 'bg-white/5 border-white/10 text-muted-foreground'}`}
                >
                  🆓 Free
                </button>
                <button
                  type="button"
                  onClick={() => setMindmapForm({ ...mindmapForm, tier: "paid" })}
                  className={`p-3 rounded-xl border text-sm font-bold transition-all ${mindmapForm.tier === 'paid' ? 'bg-primary/10 border-primary/40 text-primary' : 'bg-white/5 border-white/10 text-muted-foreground'}`}
                >
                  👑 Paid
                </button>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setIsAddingMindmap(false)}>Cancel</Button>
            <Button onClick={handleAddMindmap} disabled={uploading}>{uploading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null} Upload Map</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
